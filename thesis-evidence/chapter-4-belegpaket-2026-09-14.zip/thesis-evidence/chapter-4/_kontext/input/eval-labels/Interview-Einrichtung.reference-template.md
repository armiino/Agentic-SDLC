# Referenz-Ledger — Annotations-Vorlage: Interview-Einrichtung

> **Zweck:** hand-vollständigen Referenz-Ledger bauen, um Recall der Auto-Extraktion zu messen
> ("fehlen wirklich Sachen aus dem Transkript?"). **Deterministisch erzeugt (kein LLM).**
> Status der fertigen Referenz: *NICHT final stabil*. Diese Datei ist eine
> Adjudikationsvorlage mit modell-entworfenen Kandidaten und einem ersten AUTOR-Review-Pass
> vom 2026-06-30. Sie ist als Recall-/Coverage-Arbeitsbasis geeignet, aber noch nicht als
> harte Gold-Referenz, bis alle MISS/NOISE-Markierungen final adjudiziert und in einen
> konsolidierten Referenz-Ledger ueberfuehrt wurden.
>
> **So adjudizierst du (pro Segment):** Lies den Rohtext. Prüfe, ob die zugeordneten Kandidaten
> alles **fachlich Relevante** des Segments abdecken. Trage unter *MISS* jeden relevanten Claim ein,
> den KEIN Kandidat abdeckt. Markiere *NOISE* für irrelevante Kandidaten. Smalltalk/Wiederholung = ok leer.
> **Segmente ohne Kandidaten (⚠) zuerst prüfen** — Haupt-Miss-Verdacht.

```text
Transkript : input/transcripts/Interview-Einrichtung.txt
Kandidaten : thesis-evidence/evidence-first-spike/semantic-ledger-extract.Interview-Einrichtung.openai_gpt-5.4.extracted.json
Segmente   : 136   davon OHNE Kandidat: 66
Kandidaten : 60   zugeordnet: 60   orphan (kein Segment-Match): 0
```

## Stabilitaetsurteil nach Re-Lesen des Transkripts

**Nicht als stabile Gold-Referenz verwenden.** Die Vorlage ist brauchbar, um gezielt zu sehen,
wo der aktuelle Extractor Kandidaten verliert, aber sie ist noch keine fertige Referenz:

- Es gibt 66 Segmente ohne Auto-Kandidat; mehrere davon enthalten fachlich relevante Claims.
- Viele spaetere Design-/UI-Details sind im 60er-Kandidatensatz nur teilweise oder gar nicht
  enthalten.
- Einige Kandidaten sind zeitlich ueberholt bzw. muessen als superseded behandelt werden
  (z. B. separate Videoseite vs. spaetere Entscheidung, Videos in Kommunikationsseiten zu
  integrieren).
- Fuer eine harte Referenz muss daraus als naechster Schritt eine konsolidierte Claim-Liste
  entstehen: ein Claim pro fachlichem Punkt, mit Status, Scope, Evidence und ggf.
  `supersededBy`.

**Erster Review-Pass:** Die folgenden Segment-Adjudikationen markieren die klaren Misses und
Noise-/Superseded-Faelle, die beim erneuten Lesen des Transkripts auffallen.

---

## Segment 0 — Speaker 2

> Wir sind die EINRICHTUNG und wir betreuen Einrichtungen und Wohngemeinschaften für Menschen mit Beeinträchtigungen. Ich bin der Gesamtleiter dieser Einrichtung und vertrete diese heute in unserem Kick-Off, um eine Idee zu erarbeiten. Die Menschen, die von uns betreut werden, haben unterschiedliche Beeinträchtigungen und werden meistens nur von langjährigen Mitarbeitern verstanden. Die Mitarbeiter sind meistens ausgebildete Heilerziehungspfleger, Pädagogen oder normale Krankenpfleger. Bei den Bewohnern ist es so, dass sie nur verbal, aber auf einer eigenen Sprache kommunizieren können oder nur nonverbal durch eine Art Gebärdensprache bzw. Ähnliches. Wir suchen nach einer Lösung, die Kommunikation zwischen den Beeinträchtigten und anderen Menschen zu verbessern und zu fördern. Wir sind auch im Zeitalter der Digitalisierung angekommen. Auch wenn es bei uns etwas langsamer voranschreitet, wollen wir mit der Zeit gehen. Deswegen würden wir natürlich eine digitale Lösung für unsere Anliegen bevorzugen, also ein Computerprogramm oder Ähnliches.

**Auto-Kandidaten (2):**
- `L001` Die Einrichtung sucht eine digitale Lösung, um die Kommunikation zwischen Menschen mit Beeinträchtigungen und anderen Personen zu verbessern bzw. zu fördern.  _[desired/desired/zielbild des systems/mvp_or_later_unclear]_
- `L002` Eine digitale App wird gegenüber nicht-digitalen Lösungen bevorzugt.  _[desired/desired/lösungsform/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Die Bewohner kommunizieren teils nur verbal in eigener Sprache bzw. nonverbal ueber Gebaerden/Aehnliches; langjaehrige Mitarbeiter verstehen sie meist besser als andere Personen. Das ist wichtiger Kontext fuer Zielnutzer, Datenmodell und Kommunikationsarten.
- NOISE (irrelevanter Kandidat): 

---

## Segment 1 — Speaker 1 ⚠ KEIN KANDIDAT

> Okay, wir können Ihr Anliegen verstehen und wir wollen zunächst einmal sagen, wie sehr wir Ihre Arbeit zu schätzen wissen. Haben Sie schon einmal mit Ihren Mitarbeitern über so eine Möglichkeit gesprochen? Wir würden gerne wissen, ob die Mitarbeiter eine Vorstellung haben, wie so ein System aussehen könnte.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 2 — Speaker 2 ⚠ KEIN KANDIDAT

> Naja, zumindest ist der Wunsch nicht von den Mitarbeitern gekommen, weil sie grundsätzlich glücklich mit der Arbeit sind. Aber es hat sich durch das Digiprosa-Projekt eine Möglichkeit für eine Weiterentwicklung in unserem Bereich ergeben. Diese Möglichkeit haben wir natürlich gleich ergriffen und sind dankbar dafür, dass es uns angeboten wurde. Das Thema Kommunikation ist bei uns täglich einer der wichtigsten Faktoren, weil man auf die Bedürfnisse der beeinträchtigten Personen eingehen muss. Und ja, wie schon gesagt, jeden Tag. Was könnten Sie sich vorstellen, wäre eine mögliche Lösung für so etwas?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Der Wunsch kam nicht direkt von den Mitarbeitern; das Digiprosa-Projekt schafft die Gelegenheit zur Weiterentwicklung. Kommunikation ist taeglich ein zentraler Faktor, um auf Beduerfnisse der Bewohner einzugehen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 3 — Speaker 1

> Grundsätzlich werden wir jetzt eine Art Anforderungsanalyse mit Ihnen und vielen weiteren Personen, die mit dem System arbeiten werden, durchführen, um herauszufinden, wo genau die Bedürfnisse liegen und was genau das System eigentlich können soll. Im Vorhinein können wir aber ausschließen, dass es sich um eine Art System handeln wird, das als Schnittstelle dient und zwischen Bewohner und zum Beispiel Betreuer hin und her übersetzt. Also was ich damit meine ist, dass es aus unserer Sicht weder möglich noch kosteneffizient wäre, ein Gerät oder System zu bauen, dass unsere Sprache in das individuell verstehende Sprachverständnis der beeinträchtigten Personen umwandelt und andersherum. Warum? Weil wir uns dann nur mit einer Person speziell befassen würden und es der Allgemeinheit keinen Nutzen liefern würde. Oder wie sehen Sie das?

**Auto-Kandidaten (2):**
- `L003` Ein System, das zwischen Bewohner und Betreuer bidirektional übersetzt, wird ausgeschlossen, weil es als weder möglich noch kosteneffizient angesehen wird.  _[rejected/must_note/lösungsausgrenzung/mvp_or_later_unclear]_
- `L004` Die genaue Ausgestaltung der Lösung ist noch offen und soll durch weitere Anforderungsanalyse mit mehreren Beteiligten erarbeitet werden.  _[open/must_clarify/anforderungserhebung/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 4 — Speaker 2

> Das ist natürlich richtig und auch nicht so, wie ich es mir vorstelle. Das Problem ist, ich weiß gar nicht genau, wie ich mir das vorstelle und hoffe, dass ihr als Team eine Idee oder Lösungen erarbeiten könnt.

**Auto-Kandidaten (2):**
- `L003` Ein System, das zwischen Bewohner und Betreuer bidirektional übersetzt, wird ausgeschlossen, weil es als weder möglich noch kosteneffizient angesehen wird.  _[rejected/must_note/lösungsausgrenzung/mvp_or_later_unclear]_
- `L004` Die genaue Ausgestaltung der Lösung ist noch offen und soll durch weitere Anforderungsanalyse mit mehreren Beteiligten erarbeitet werden.  _[open/must_clarify/anforderungserhebung/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 5 — Speaker 1 ⚠ KEIN KANDIDAT

> Ja, das hoffen wir auch. Unser Team besteht ja auch bewusst aus zwei Informatikern und zwei sozialen Arbeitsstudierenden. Wir haben also das nötige technische und auch das hier gebrauchte pädagogische und soziale Wissen. Und deswegen führen wir auch dieses Interview, um gemeinsam die nötigen Punkte zu erarbeiten. Wie sieht es mit Dokumentationen aus? Also wird irgendwo festgehalten, wie ein Bewohner der Einrichtung kommuniziert, was für eine Diagnose er oder sie hat und so weiter?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 6 — Speaker 2

> Ja, es gibt natürlich klassische Akten, wo alles über die Bewohner der Einrichtung festgehalten und dokumentiert wird.

**Auto-Kandidaten (1):**
- `L005` Es existieren klassische Akten, in denen Informationen über Bewohner dokumentiert werden.  _[decided/must_note/bestandsprozess/datenquelle/-]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 7 — Speaker 1 ⚠ KEIN KANDIDAT

> Das ist schon mal gut zu wissen. Wäre es eventuell möglich, eine beeinträchtigte Person kennenzulernen? Also das, was wir als Team gemeinsam in Begleitung eines Heileziehungspflegers in eine ihrer Einrichtungen fahren, um die Situation besser einschätzen zu können. Wir denken, es wäre vom Vorteil zu sehen, wie die Kommunikation aktuell abläuft und wie und wo die Bedürfnisse allgemein liegen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Ein Kennenlern-/Beobachtungstermin in Begleitung eines Heilerziehungspflegers soll helfen, aktuelle Kommunikation und Beduerfnisse real zu verstehen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 8 — Speaker 2 ⚠ KEIN KANDIDAT

> Ja, wir können gerne einen Termin für so einen Kennenlern-Tag ausmachen. Wir können auch gerne in mehrere Einrichtungen fahren, um ein größeres Gesamtbild der Einrichtung-NoName zu schaffen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Die Einrichtung bietet einen Kennenlern-Tag an und ist bereit, mehrere Einrichtungen zu zeigen, um ein groesseres Gesamtbild zu bekommen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 9 — Speaker 1 ⚠ KEIN KANDIDAT

> Perfekt. Da das Thema unterstützende Kommunikation ist, stellen wir uns auch die Frage, aus wessen Sicht die Unterstützung kommen soll. Also sollen die Beeinträchtigten unterstützt werden, um beispielsweise die Betreuer besser zu verstehen oder andersherum? Ich denke, logischerweise wäre es besser, wenn man ein System hätte, das einem hilft, den Bewohner besser zu verstehen als andersherum. Aber wie sehen Sie das?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 10 — Speaker 2

> Ja, wenn man sich entscheiden müsste, wäre es auf jeden Fall sinnvoller, wenn man einen Weg finden würde, die Bewohner besser zu verstehen.

**Auto-Kandidaten (1):**
- `L008` Der Hauptnutzen soll darin liegen, dass Betreuer bzw. andere Personen Bewohner besser verstehen können; Unterstützung in die umgekehrte Richtung ist nicht priorisiert.  _[decided/must_note/kommunikationsrichtung/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 11 — Speaker 1

> Wir glauben auch, dass es schwierig wäre, einen Weg zu finden, dass alle Beeinträchtigten Techniken oder Systeme nutzen, die es ermöglichen, die Betreuer zu verstehen. Dafür müsste man wahrscheinlich für jeden individuell etwas entwickeln. Also haben wir dabei einen Weg zu finden, wie der Betreuer jeden Bewohner besser verstehen kann. Was halten Sie von der Idee, eine App zu entwickeln, aus der Daten, aus der Akte bzw. allgemeines Wissen der Art und Weise, wie eine beeinträchtigte Person kommuniziert festgehalten wird? Diese App wäre für jeden, der mit einer Person, die er nicht verstehen kann, eine Lösung, um nachzuschauen, was gemeint sein könnte. Die App sollte mehrere Anforderungen erfüllen, die wir noch erarbeiten müssen. Aber als Vorschlag könnte die App so aufgebaut sein, dass es einen Teil gibt, der als allgemeines Kennenlernenfeld betrachtet werden kann, also wo man quasi draufklickt und durch mehrere Bilder mit Texten einfach einen ersten Eindruck der Person bekommt und sie so etwas kennenlernt. Wir denken da auch an Hobbys und alles, was die Person etwas näher beschreibt. Die weiteren Teile befassen sich dann damit, irgendwie die Kommunikation zu unterstützen. Das muss dann noch weiter erarbeitet werden.

**Auto-Kandidaten (2):**
- `L008` Der Hauptnutzen soll darin liegen, dass Betreuer bzw. andere Personen Bewohner besser verstehen können; Unterstützung in die umgekehrte Richtung ist nicht priorisiert.  _[decided/must_note/kommunikationsrichtung/mvp_or_later_unclear]_
- `L010` Die App soll pro Bewohner eine About-Me-Seite mit persönlichen Basisinformationen wie Hobbys, Name, Alter, Bildern und Beschreibungen enthalten.  _[desired/desired/profil/about me/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Die App-Idee umfasst nicht nur eine About-Me-Seite, sondern auch das Festhalten von Aktenwissen bzw. allgemeinem Wissen zur individuellen Kommunikationsweise, damit andere Personen nachschauen koennen, was gemeint sein koennte.
- NOISE (irrelevanter Kandidat): 

---

## Segment 12 — Speaker 2

> Diese Idee hört sich super an. Also Sie denken da an eine App, die jeder bei sich im Handy hat, um in jeder Situation etwas nachprüfen zu können? Man könnte auch die Medikamentenvergabe als Terminkalender hinzufügen und die App generell für mehrere Sachen hernehmen?

**Auto-Kandidaten (1):**
- `L019` Ein Kalender bzw. Terminübersicht wurde als mögliche Funktion genannt; in der Einrichtung existiert bereits ein großer Wandkalender für Termine.  _[optional/optional/kalender/termine/later_possible]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Die App soll perspektivisch auf dem Handy verfuegbar sein, damit man in jeder Situation etwas nachpruefen kann.
- NOISE (irrelevanter Kandidat): 

---

## Segment 13 — Speaker 1

> Genau, das lässt sich beliebig erweitern mit Funktionen. Wir müssten das natürlich noch ausarbeiten und genau planen, damit das Sinn macht. Das wird sich dann im Laufe unserer Anforderungsanalyse ergeben. Im Rahmen der Anforderungsanalyse, um die Anforderungen an die App genau zu besprechen, ist es für uns sowieso am besten, wenn wir alle oder zumindest einige der Beteiligten und Nutzer der App kennenlernen könnten, damit auch ihre Bedürfnisse berücksichtigt werden. Halten wir also für das erste Gespräch mal fest. Sie wollen eine App, die die Kommunikation zwischen einer beeinträchtigten Person und einer beliebigen anderen Person unterstützt, ermöglicht oder verbessert. Eine Idee wäre es, eine App zu programmieren, die genaues über die Art und Weise, wie eine Person kommuniziert, enthält, sodass zum Beispiel jeder Betreuer die Möglichkeit hätte, wenn er mit Person X kommunizieren möchte, die Person X aber nicht verstehen kann, in der App nachschauen kann, was gemeint sein könnte, oder? Wie und was die App genau können soll, werden wir in den nächsten Terminen erarbeiten.

**Auto-Kandidaten (1):**
- `L002` Eine digitale App wird gegenüber nicht-digitalen Lösungen bevorzugt.  _[desired/desired/lösungsform/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): In der weiteren Anforderungsanalyse sollen alle oder zumindest einige Beteiligte/Nutzer kennengelernt werden, damit deren Beduerfnisse beruecksichtigt werden.
- NOISE (irrelevanter Kandidat): 

---

## Segment 14 — Speaker 2 ⚠ KEIN KANDIDAT

> Ja, das hört sich schon mal vielversprechend an. Im nächsten Termin werde ich dafür sorgen, dass ein Heilerziehungspfleger mit dabei ist, damit ihr dort auch weitere Fragen stellen könnt. Vielen Dank für das erste Gespräch und bis bald.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 15 — Speaker 1 ⚠ KEIN KANDIDAT

> Bis bald. 2. Interview-Heilerziehungspflegerin

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 16 — Speaker 1 ⚠ KEIN KANDIDAT

> Das war eine neue und sehr interessante Erfahrung für uns und im ersten Moment etwas überfordernd, um ehrlich zu sein. Uns ist aufgefallen, dass wir und wahrscheinlich alle Personen, die den Hubert das erste Mal sehen, nicht mit ihm kommunizieren können. Also stellt sich uns auch die Frage, dokumentieren sie ihr Wissen? Wir haben gemerkt, dass sie wissen, wenn er beispielsweise mit dem Fuß eine bestimmte Bewegung macht, was er meint. Vielleicht etwas allgemeiner, wie sehen die Akten eines Bewohners aus? Werden die regelmäßig erweitert oder gelesen?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Neue oder fremde Personen koennen mit Hubert bzw. Bewohnern anfangs nicht kommunizieren; erfahrene Betreuer koennen konkrete nonverbale Zeichen deuten. Das begruendet den Bedarf nach schnell abrufbarem Erfahrungswissen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 17 — Speaker 2

> Grundsätzlich wird alles nach einem bestimmten Plan dokumentiert. Auch Erfahrungen und neues Wissen wird schriftlich festgehalten. Ob sie gelesen werden, kann ich nicht persönlich beantworten, weil ich sie definitiv nicht lese. Es ist einfach zu viel zu lesen und oft findet man auch nicht das, wonach man sucht. Aber der Grund dafür, dass ich es nicht lese, ist meine Erfahrung.

**Auto-Kandidaten (1):**
- `L006` Wissen über Kommunikationsweisen wird zwar schriftlich dokumentiert, die bestehende Dokumentation ist aber im Alltag oft schwer lesbar und wenig schnell auffindbar.  _[required/must/nutzwert gegenüber bestandsdokumentation/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 18 — Speaker 1 ⚠ KEIN KANDIDAT

> Okay, also ist die Dokumentation im Nachhinein eher weniger hilfreich. Wäre es möglich, so eine Dokumentation mal zu sehen?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 19 — Speaker 2

> So würde ich es auch nicht direkt betiteln. Das war nur meine persönliche Meinung zu der Frage. Das Einsehen so einer Akte könnte eher schwierig aufgrund von Datenschutz werden. Aber ich werde mich mal umhören und euch Bescheid geben, falls es doch möglich sein sollte.

**Auto-Kandidaten (1):**
- `L022` Das Einsehen bestehender Bewohnerakten durch das Projektteam ist aufgrund von Datenschutz schwierig und unklar.  _[uncertain/must_consider/akteneinsicht/datenschutz/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 20 — Speaker 1 ⚠ KEIN KANDIDAT

> Wir sind nicht die Einzigen, die den Bewohner das erste Mal sehen. Wie geht ihr zum Beispiel mit neuen Mitarbeitern um? Wie schaffen die es, mit den Bewohnern zu kommunizieren?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 21 — Speaker 2

> Das läuft recht unterschiedlich ab. Im Normalfall gibt es erstmals natürlich die Dokumentationen. Ansonsten werden die neuen Mitarbeiter so eingearbeitet, dass immer jemand mit dabei ist, bis der neue Mitarbeiter und die Bewohner sich gut genug kennengelernt haben und sich weitestgehend verstehen. Da spielt natürlich auch das Vertrauen, das erst mal aufgebaut werden muss, eine große Rolle. Aber das heißt, im Endeffekt erklären wir den Neuen immer, was gemeint ist, wenn sie mit den Bewohnern versuchen zu kommunizieren.

**Auto-Kandidaten (1):**
- `L009` Das System soll insbesondere neuen Mitarbeitern helfen, ohne lange Einarbeitung Bewohner besser zu verstehen.  _[desired/desired/zielnutzer/nutzenszenario/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 22 — Speaker 1

> Okay, also zur Wiederholung. Das bedeutet, dass Sie und alle anderen, die länger mit den Beeinträchtigten zu tun hatten, das nötige Wissen für eine mögliche Kommunikation besitzen, oder? Man müsste sich nur einen Weg überlegen, wie man das Wissen festhalten und schnell abrufen könnte. Wir haben in unserem Erstgespräch mit dem Gesamtleiter der Einrichtungen eine Idee erarbeitet. Die Grundidee dafür ist eine App, in der man das nötige Wissen über die verschiedenen Kommunikationsweisen der Bewohner festhalten könnte. Das Ziel dabei ist, eine Kommunikation zu ermöglichen. Also könnte damit jeder andere neue Mitarbeiter durch diese App den Bewohner verstehen. Da müssen Sie auch nicht extra Zeit für eine Einarbeitung investieren und könnten ruhigen Gewissens jeden neuen Mitarbeiter oder jede beliebige Person mit den Beeinträchtigten alleine lassen.

**Auto-Kandidaten (2):**
- `L007` Das System soll Wissen über individuelle Kommunikationsweisen von Bewohnern festhalten und schnell abrufbar machen.  _[required/must/kernfunktion kommunikation/mvp_or_later_unclear]_
- `L009` Das System soll insbesondere neuen Mitarbeitern helfen, ohne lange Einarbeitung Bewohner besser zu verstehen.  _[desired/desired/zielnutzer/nutzenszenario/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 23 — Speaker 2

> Das wäre traumhaft. Und ehrlich gesagt sind wir hier sehr analog unterwegs und haben noch nicht viel von Digitalisierung erlebt. Alles, was digitalisiert werden kann, wäre für uns von großem Vorteil. Somit auch eventuell die ganze Dokumentation?

**Auto-Kandidaten (1):**
- `L020` Eine vollständige Übernahme der gesamten Dokumentation in die App ist noch nicht entschieden und sollte wegen Umfang und Fokus begrenzt betrachtet werden.  _[open/must_clarify/dokumentationsumfang/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Die Einrichtung arbeitet stark analog; Digitalisierung allgemein wird als grosser Vorteil gesehen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 24 — Speaker 1

> Ja, das wäre natürlich auch möglich. Jedoch wäre es wichtig, die App mit Grenzen zu betrachten. Je mehr sie leisten muss, desto schwerer wird es, desto länger dauert es und ich vermute, desto weniger Freude wird man an dieser App haben. Dennoch werden wir das mit in unsere Anforderungen packen und mit dem Leiter des Einrichtung-NoName, der am Ende auch alles absegnen muss, klären, ob eine volle Dokumentation von der App übernommen werden soll. Auch wenn ich hier schon mal sagen werde, dass es nicht so einen großen Umfang haben sollte, da nicht der eigentliche Sinn der unterstützenden Kommunikation verloren gehen soll. Hätten Sie sonst noch Vorschläge, was wir mit der App noch machen sollen? Wir haben uns schon mal zwei Punkte überlegt, die die App leisten soll. Erstens soll es einen Button geben, der zu einem Feld führt, dem wir als About Me Seite ausgearbeitet haben. Also eine Seite, die erstmal für den ersten Eindruck der Person sorgt, mit Bildern, Beschreibungen, Hobbys, Name, Alter und so weiter. Die Bilder sollen etwas Social Media ähneln und erweiterbar sein. Also man kann immer neue Bilder mit einer Beschreibung hinzufügen. Später hat man eine lange Liste, wie zum Beispiel in Instagram und kann nach unten scrollen und sich die Bilder anschauen und so etwas über die Person erfahren. Daher auch der Name About Me. Wir wollen dadurch erreichen, dass ein erster Eindruck entsteht. Natürlich auch für neue Betreuer, die sich im Vorhinein eben ein gutes Bild über den Bewohner machen können. Der zweite Button führt zu einem Kommunikationsscreen. Diesen wollen wir in verbal und nonverbal unterteilen. Unser Ziel ist da, dann die Daten über das Verständnis verschiedener Kommunikationsweisen zu speichern und dann für alle Benutzer jederzeit abrufbar zu machen. Und wir haben uns überlegt, da die App immer bei einem in der Hosentasche ist, eventuell noch eine Medikamentenvergabe und Terminkalenderseite zu bauen, um immer abrufbar zu haben, was die Person braucht oder für Termine hat. Wie regeln Sie das sonst?

**Auto-Kandidaten (5):**
- `L010` Die App soll pro Bewohner eine About-Me-Seite mit persönlichen Basisinformationen wie Hobbys, Name, Alter, Bildern und Beschreibungen enthalten.  _[desired/desired/profil/about me/mvp_or_later_unclear]_
- `L011` About-Me-Inhalte sollen dynamisch erweiterbar sein; neue Bilder mit Beschreibung sollen hinzugefügt werden können.  _[desired/desired/profil/about me bearbeitung/mvp_or_later_unclear]_
- `L013` Die App soll eine Kommunikationsseite pro Bewohner enthalten, unterteilt in verbale und nonverbale Kommunikation.  _[desired/desired/kommunikationsscreen/mvp_or_later_unclear]_
- `L019` Ein Kalender bzw. Terminübersicht wurde als mögliche Funktion genannt; in der Einrichtung existiert bereits ein großer Wandkalender für Termine.  _[optional/optional/kalender/termine/later_possible]_
- `L020` Eine vollständige Übernahme der gesamten Dokumentation in die App ist noch nicht entschieden und sollte wegen Umfang und Fokus begrenzt betrachtet werden.  _[open/must_clarify/dokumentationsumfang/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Eine vollstaendige Dokumentationsuebernahme muss vom Gesamtleiter final abgesegnet werden; zu grosser Funktionsumfang gefaehrdet Aufwand, Dauer, Nutzungsfreude und Fokus auf unterstuetzende Kommunikation.
- NOISE (irrelevanter Kandidat): 

---

## Segment 25 — Speaker 2

> Das hört sich schon mal sehr gut an. Wie habt ihr euch das aber mit der Kommunikationsseite genau vorgestellt? Also ich nehme an, dass das Wissen genau wie bei dem About Me dynamisch wachsen soll. Neue Erfahrungen müssen hinzugefügt werden können. Und bezüglich des Terminkalenders, normalerweise haben wir hier dafür einen großen Kalender an der Wand, den ich euch gerne zeigen kann. Da wird alles übersichtlich angezeigt. Medikamente werden etwas vertraulicher gehandhabt.

**Auto-Kandidaten (4):**
- `L010` Die App soll pro Bewohner eine About-Me-Seite mit persönlichen Basisinformationen wie Hobbys, Name, Alter, Bildern und Beschreibungen enthalten.  _[desired/desired/profil/about me/mvp_or_later_unclear]_
- `L015` Kommunikationsinhalte sollen dynamisch wachsen; neue Erfahrungen müssen hinzugefügt werden können.  _[desired/desired/kommunikationswissen pflege/mvp_or_later_unclear]_
- `L019` Ein Kalender bzw. Terminübersicht wurde als mögliche Funktion genannt; in der Einrichtung existiert bereits ein großer Wandkalender für Termine.  _[optional/optional/kalender/termine/later_possible]_
- `L021` Medikamenteninformationen sind vertraulich und müssen sensibler behandelt werden als allgemeine Termine.  _[decided/must_consider/medikationsdaten/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 26 — Speaker 1

> Ja, wir haben uns gedacht, dass man das eben auch durch einen Plus-Button alles erweitern kann. Wie genau das umgesetzt werden soll, muss noch erarbeitet und geklärt werden. Wir dachten uns aber, dass es Sinn machen würde, visuelle Darstellungen zu präsentieren. Bilder, Texte und so weiter. Haben Sie eine Idee?

**Auto-Kandidaten (1):**
- `L014` Kommunikationswissen soll durch Texte, Bilder und andere visuelle Darstellungen festgehalten werden, nicht nur durch Text.  _[desired/desired/kommunikationsdaten darstellung/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 27 — Speaker 2

> Ja, es wäre auf jeden Fall vom Vorteil, wenn da nicht nur Texte stehen würden, sondern andere mögliche Darstellungen.

**Auto-Kandidaten (1):**
- `L014` Kommunikationswissen soll durch Texte, Bilder und andere visuelle Darstellungen festgehalten werden, nicht nur durch Text.  _[desired/desired/kommunikationsdaten darstellung/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 28 — Speaker 1

> Könnten Sie sich um die Datenschutzthematik kümmern und mit den Angehörigen reden, ob es in Ordnung wäre, wenn wir Bilder machen bzw. bekommen, um sie in die App später mal testweise einzuflegen?

**Auto-Kandidaten (1):**
- `L023` Für Bilder der Bewohner in der App ist Datenschutz-/Einwilligungsklärung mit Angehörigen erforderlich.  _[open/must_clarify/bilder/medien von bewohnern/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 29 — Speaker 2

> Ja, natürlich. Das kann ich gerne machen.

**Auto-Kandidaten (1):**
- `L023` Für Bilder der Bewohner in der App ist Datenschutz-/Einwilligungsklärung mit Angehörigen erforderlich.  _[open/must_clarify/bilder/medien von bewohnern/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 30 — Speaker 1

> Fänden Sie es sinnvoll, in Form von Videos gewisse Szenarien abzufilmen und diese dann in der App mit einer Beschreibung zu präsentieren? Wir haben ja vorhin bei dem Kennenlernen von Hubert erkannt, dass er gerne etwas mit dem Fuß zeigt und damit auch Aussagen möchte. Wir konnten das nicht verstehen, aber Sie mit Ihrem Wissen über seine Kommunikationsweise haben das sofort erkannt und gedeutet. Das macht er sicherlich öfter, oder? Also stellen Sie sich vor, Sie würden die Situation von Hubert mit dem Fuß, also die Situation, wo Hubert mit dem Fuß deutet, abfilmen und interpretieren, sodass jemand anderes sich das anschauen kann und die Situation wiedererkennen kann. Was halten Sie davon?

**Auto-Kandidaten (2):**
- `L016` Eine eigenständige Videoseite zum Festhalten von Szenarien und Verhaltensweisen wurde als gute Idee aufgenommen, insbesondere für Neubetreuer.  _[desired/desired/video-dokumentation/later_possible]_
- `L017` Videos mit Beschreibung sollen helfen, wiederkehrende nonverbale Situationen und deren Interpretation nachvollziehbar zu machen.  _[desired/desired/video-nutzwert/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): L016 ist als eigenstaendige Videoseite spaeter durch L038 superseded; als historische Idee ok, aber nicht als finale Struktur werten.

---

## Segment 31 — Speaker 2

> Das ist eine sehr gute Idee. Machen Sie noch eine Videoseite, wo man so etwas machen kann. Ich kann mir gut vorstellen, dass es gerade Neubetreuern helfen würde, aber natürlich auch allen anderen.

**Auto-Kandidaten (2):**
- `L016` Eine eigenständige Videoseite zum Festhalten von Szenarien und Verhaltensweisen wurde als gute Idee aufgenommen, insbesondere für Neubetreuer.  _[desired/desired/video-dokumentation/later_possible]_
- `L017` Videos mit Beschreibung sollen helfen, wiederkehrende nonverbale Situationen und deren Interpretation nachvollziehbar zu machen.  _[desired/desired/video-nutzwert/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): L016 ist als eigenstaendige Videoseite spaeter durch L038 superseded; als historische Idee ok, aber nicht als finale Struktur werten.

---

## Segment 32 — Speaker 1

> Okay, danke für den Input. Ich wiederhole mal. Es wird schon mal drei Buttons geben, die zu bestimmten Seiten führen. Einmal about me, also über mich. Diese Seite verschafft dem Benutzer einen ersten Eindruck über die Person und bietet ein Infofeld, wo bestimmte Informationen gelistet sind. Darunter wird eine Liste von Bildern sein, die an Social Media erinnern sollen. Diese Bilder werden mit einer Beschreibung versehen. Es gibt also irgendwo, am besten unten in der Mitte, einen Button mit einem Plus-Symbol, welcher einen Dialog öffnet. Der es ermöglicht, ein Foto hinzuzufügen und einen Text dafür zu schreiben. Das neueste hinzugefügte Foto wird immer oben angezeigt. Die Liste der Fotos wächst also nach oben, sodass man immer das aktuelle Bild sehen kann. Ein zweiter Button wird zu einer Seite führen, die eine Kommunikationsseite ist. Dort gibt es eine weitere Unterteilung in verbal und nonverbal. Wahrscheinlich macht es hier auch Sinn, noch zwei Buttons zu erstellen, die dann zu den jeweiligen Seiten navigieren, wenn man draufklickt. Hier werden die verbalen und nonverbalen Kommunikationsarten durch Texte, Bilder etc. festgehalten, genauso wie beim About Me Screen. Wird auch hier die Möglichkeit sein, diese Liste an Kommunikationsarten dynamisch zu erweitern. Also durch einen Button am Boden, der die Seite, der dann wiederum einen Dialog öffnet, in dem man Texte schreiben kann und Bilder hinzufügen natürlich. Der dritte Button führt zu einer Videoseite. Diese Seite soll den Sinn haben, Videos zu bestimmen. Videos zu bestimmten Situationen zu enthalten. Das bedeutet also, dass wenn man ein unbekanntes Verhalten bzw. eine unbekannte Kommunikationsart des Beeinträchtigten sieht, man sie dort als Video finden kann. Auch wenn man eine neue Situation erkennt und eine neue Erfahrung der Kommunikation macht, soll diese hinzugefügt werden können. Wie gewohnt durch einen Button am Ende des Bildschirms, der wohl die Funktionalität hat, ein neues Video mit einer Beschreibung hinzuzufügen.

**Auto-Kandidaten (4):**
- `L011` About-Me-Inhalte sollen dynamisch erweiterbar sein; neue Bilder mit Beschreibung sollen hinzugefügt werden können.  _[desired/desired/profil/about me bearbeitung/mvp_or_later_unclear]_
- `L012` Neue About-Me-Einträge sollen als neueste Elemente oben in einer scrollbaren Liste angezeigt werden.  _[desired/desired/profil/about me darstellung/mvp_or_later_unclear]_
- `L013` Die App soll eine Kommunikationsseite pro Bewohner enthalten, unterteilt in verbale und nonverbale Kommunikation.  _[desired/desired/kommunikationsscreen/mvp_or_later_unclear]_
- `L015` Kommunikationsinhalte sollen dynamisch wachsen; neue Erfahrungen müssen hinzugefügt werden können.  _[desired/desired/kommunikationswissen pflege/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Die in diesem Segment wiederholte eigenstaendige Videoseite mit Video-plus-Beschreibung ist fachlich relevant, wird aber spaeter durch die Entscheidung ersetzt, Videos in die Kommunikationsseiten zu integrieren.
- NOISE (irrelevanter Kandidat): Die eigenstaendige Videoseite ist spaeter durch Integration in Kommunikationsseiten superseded; Referenz sollte `supersededBy: L038` fuehren statt beide als gleichzeitige finale Anforderungen zu zaehlen.

---

## Segment 33 — Speaker 2 ⚠ KEIN KANDIDAT

> Ja, das hört sich schon mal sehr vielversprechend an. Aber wer wird denn alles Zugriff drauf haben können?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 34 — Speaker 1 ⚠ KEIN KANDIDAT

> Wir haben jetzt eigentlich nur die Mitarbeiter eingeplant. An wen haben Sie gedacht?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 35 — Speaker 2

> Ich fände es sehr sinnvoll, wenn auch die Angehörigen Zugriff drauf hätten. Aus dem Grund, weil sie logischerweise die Personen noch besser kennen als wir die meisten. Wenn die auch ihre Daten da hinzufügen können, ist es von Vorteil, da sie oftmals Sachen wissen, die wir erst erfahren müssten.

**Auto-Kandidaten (1):**
- `L028` Angehörige sollen ebenfalls Zugriff auf die App erhalten und Inhalte beitragen können, da sie Bewohner oft besonders gut kennen.  _[desired/desired/nutzergruppen angehörige/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 36 — Speaker 1

> Alles klar. Wenn Sie das möchten, dann machen wir das so, dass es verschiedene Accounts gibt. Also Mitarbeiter und Angehörige, die vermutlich auch verschiedene Rechte haben werden. Durch die Angehörigenaccounts hätten Sie auch Vorteile, wenn Sie neue Bewohner bekommen. Sie könnten für die Angehörigen im Vorhinein einen Account erstellen und die App mit Daten füllen lassen. So würden Sie sich Zeit sparen und müssten nicht erstmal die Person von Null auf kennenlernen.

**Auto-Kandidaten (2):**
- `L028` Angehörige sollen ebenfalls Zugriff auf die App erhalten und Inhalte beitragen können, da sie Bewohner oft besonders gut kennen.  _[desired/desired/nutzergruppen angehörige/mvp_or_later_unclear]_
- `L029` Angehörigenzugriff soll auch dazu dienen, bei neuen Bewohnern Daten bereits vorab einzupflegen und so Einarbeitungszeit zu sparen.  _[desired/desired/onboarding neuer bewohner/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 37 — Speaker 2

> Das ist eine fabelhafte Idee. Ich bin überzeugt von Ihrer App.

**Auto-Kandidaten (1):**
- `L029` Angehörigenzugriff soll auch dazu dienen, bei neuen Bewohnern Daten bereits vorab einzupflegen und so Einarbeitungszeit zu sparen.  _[desired/desired/onboarding neuer bewohner/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 38 — Speaker 1

> Wir haben uns auch noch einen weiteren Punkt überlegt. Wie wäre es neben dem About Me, Kommunikation, Video und Kalenderbildschirm noch ein No-Go Bildschirm zu haben? Da sollte man dann festhalten, was absolut gar nicht geht in Gegenwart des Bewohners. Nehmen wir an, der Bewohner kann sich nur nonverbal ausdrücken und ist Epileptiker. Er wird nicht so leicht einfach jemanden signalisieren können, dass er kein flackerndes Licht ertragen kann.

**Auto-Kandidaten (1):**
- `L018` Eine No-Go-Seite mit Dingen, die in Gegenwart des Bewohners unbedingt vermieden werden sollen, wird als sehr wichtig angesehen.  _[desired/desired/no-go/verbote/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 39 — Speaker 2

> Das hört sich auch sehr gut an. Diese No-Go Seite ist wirklich sehr wichtig. Die Thematik wird generell sehr unterschätzt.

**Auto-Kandidaten (1):**
- `L018` Eine No-Go-Seite mit Dingen, die in Gegenwart des Bewohners unbedingt vermieden werden sollen, wird als sehr wichtig angesehen.  _[desired/desired/no-go/verbote/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 40 — Speaker 1 ⚠ KEIN KANDIDAT

> Alles klar. Vielen Dank und bis bald. Wir halten Sie auf dem Laufenden. 3. Erste-Ausarbeitung-Stundenten

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 41 — Speaker 2 ⚠ KEIN KANDIDAT

> Okay, also lassen wir uns die Struktur unserer App jetzt durchgehen, um sicherzustellen, dass alles sinnvoll und benutzerfreundlich ist. Wir starten mit einem Login-Screen. Was ist da wichtig?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 42 — Speaker 1

> Ja, beim Thema Login sollten wir verschiedene Account-Typen haben. User und Admin wäre mal ein Anfang. Der Admin hat dabei mehr Rechte und kann neue Accounts anlegen und diese verwalten, während die User-Accounts nur User-Rechte haben. Als Betreuer und Angehörige wären solche User und die können nur Inhalte hinzufügen, aber nichts löschen. Was hältst du davon?

**Auto-Kandidaten (2):**
- `L025` Accounts sollen durch einen Admin angelegt und verwaltet werden; es gibt mindestens Rollen Admin und User.  _[decided/must/rollen- und rechtemodell/mvp]_
- `L026` User sollen Inhalte hinzufügen, aber keine Daten löschen können; Admins können alles.  _[decided/must/rechte auf inhaltsänderung/mvp]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 43 — Speaker 2

> Das klingt gut. Wie wir den Login-Screen dann vom Design her gestalten, klären wir wann anders. Lass uns erstmal auf die Funktionalitäten beschränken und dann weiterschauen. Es wird also nur eine Login-Möglichkeit da sein. Wir haben schon besprochen, dass man sich nicht registrieren können soll und nur ein Account mit Admin-Rechten weitere Accounts erstellen kann und die Rechte verwaltet. Wo kommen wir nach dem Login hin?

**Auto-Kandidaten (2):**
- `L024` Die App soll nur nach Login zugänglich sein; offene Selbstregistrierung ist nicht vorgesehen.  _[decided/must/zugriffsschutz/authentifizierung/mvp]_
- `L025` Accounts sollen durch einen Admin angelegt und verwaltet werden; es gibt mindestens Rollen Admin und User.  _[decided/must/rollen- und rechtemodell/mvp]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 44 — Speaker 1

> Ja, so umgehen wir etwas das Datenschutz-Thema und es kann sich nicht jeder beliebige bei der App registrieren und auf Daten zugreifen. Ich würde sagen, nach dem Login landet man auf einer Profilübersicht-Seite. Dort zeigen wir eine Liste aller Profile an. Jedes Profil ist anklickbar und führt zu einer weiteren Seite. Also speziell nur die weiteren Daten von dem gewählten Profil.

**Auto-Kandidaten (3):**
- `L024` Die App soll nur nach Login zugänglich sein; offene Selbstregistrierung ist nicht vorgesehen.  _[decided/must/zugriffsschutz/authentifizierung/mvp]_
- `L046` Die App soll eine Profilübersicht mit einer Liste aller Profile bereitstellen, von der aus einzelne Profile geöffnet werden können.  _[decided/must/navigation/profilübersicht/mvp_or_later_unclear]_
- `L060` Die App soll ohne öffentliche Registrierung gestaltet werden, um unbefugten Zugang zu sensiblen Daten zu verhindern.  _[decided/must_note/sicherheitsbegründung zugangsmodell/mvp]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 45 — Speaker 2 ⚠ KEIN KANDIDAT

> Perfekt. In jedem Profil haben wir dann drei weitere Seiten, die man navigieren könnte. About Me, Kommunikation und Video plus den Kalender. Beginnen wir mit About Me. Was denkst du sollte da alles rein?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): In jedem Profil sind als Hauptbereiche About Me, Kommunikation, Video und Kalender vorgesehen; diese Navigationsstruktur ist hier explizit zusammengefasst.
- NOISE (irrelevanter Kandidat): 

---

## Segment 46 — Speaker 1 ⚠ KEIN KANDIDAT

> About Me sollte wirklich informativ und persönlich sein. Wir könnten ein Informationsfeld mit Hobbys, Namen, Alter und so weiter einrichten. Dazu Bilder mit Beschreibungen und natürlich den Plus-Button am unteren Ende des Bildschirms, um neue Bilder hinzuzufügen. Das aktuellste Bild sollte immer ganz oben stehen und man kann dann klassisch runterscrollen und den Rest anschauen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): About Me soll informativ/persoenlich sein und ein Informationsfeld plus Bilder mit Beschreibungen und Plus-Button enthalten; das aktuellste Bild soll oben stehen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 47 — Speaker 2 ⚠ KEIN KANDIDAT

> Klingt super. Also der Plus-Button soll dann sozusagen ein weiteres Fenster öffnen, wo man alles hinzufügen kann, wie zum Beispiel Bilder und die Beschreibung. Diese werden dann automatisch ganz oben als neuestes Bild angezeigt und so weiter. Und für die Kommunikation, wie teilen wir das auf?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Der Plus-Button soll ein Eingabefenster/Dialog fuer Bilder und Beschreibungen oeffnen; neue Inhalte werden automatisch oben einsortiert.
- NOISE (irrelevanter Kandidat): 

---

## Segment 48 — Speaker 1 ⚠ KEIN KANDIDAT

> Ich denke es wäre sinnvoll, es in verbal und nonverbal zu unterteilen. Jeder Bereich könnte eigene Buttons haben, die dann auf die entsprechenden Bildschirme weiterleiten. Dort kann jeder Nutzer neue Kommunikationsweisen hinzufügen, wie Texte oder Bilder. Hier haben die Bildschirme dann ähnlich wie der About-Me-Screen unten einen Plus-Button, der die Seite erweitert.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Verbale und nonverbale Kommunikationsbereiche sollen eigene Buttons bzw. Unterseiten haben; Nutzer sollen dort Kommunikationsweisen mit Texten/Bildern hinzufuegen koennen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 49 — Speaker 2 ⚠ KEIN KANDIDAT

> Ja, ich finde auch, dass es so am besten ist. Was ist mit dem Kalender?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 50 — Speaker 1 ⚠ KEIN KANDIDAT

> Der Kalender sollte einfach und übersichtlich sein. Er könnte nicht nur Termine, sondern auch Medikamentengaben enthalten, was enorm wichtig ist. Also einfach anklickbare Tage des Monats, wo man klassisch einen Eintrag hinzufügen kann und darunter eine Liste mit Medikamenten.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Der Kalender soll einfach/uebersichtlich sein, anklickbare Monatstage bieten und Termine sowie Medikamentengaben als Eintraege anzeigen koennen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 51 — Speaker 2 ⚠ KEIN KANDIDAT

> Absolut, das vereinfacht die tägliche Routine. Und die Videoseite, wie wollen wir uns das vorstellen?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 52 — Speaker 1 ⚠ KEIN KANDIDAT

> Auf der Videoseite könnten wir einen Bereich einrichten, wo neue Videos leicht hinzuzufügen sind. Ein Plus-Button unten auf dem Bildschirm ermöglicht das Hinzufügen neuer Videos mit Beschreibungen. Auch hier sollte das neueste Video oben angezeigt werden.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Videos sollen leicht ueber einen Plus-Button mit Beschreibung hinzufuegbar sein; das neueste Video soll oben angezeigt werden. Spaeter als eigenstaendige Videoseite durch Integration in Kommunikationsseiten superseded.
- NOISE (irrelevanter Kandidat): 

---

## Segment 53 — Speaker 2

> Das wird super nützlich sein, um bestimmte Verhaltensweisen oder Kommunikationsarten visuell festzuhalten. Wir sollten nicht vergessen, eine Appbar oben im Bildschirm zu programmieren. Mit der kann man dann zurücknavigieren oder sich ausloggen über ein Logout-Symbol. Diese Appbar sollte nach dem Login auf jeder Seite oben sein. Vielleicht wäre auch ein Einstellungssymbol in der Appbar sinnvoll, damit man zu den Einstellungen kommen kann. Da müssen wir uns auch noch was überlegen.

**Auto-Kandidaten (3):**
- `L047` Nach dem Login soll auf allen Seiten eine konsistente Appbar mit Rücknavigation, aktuellem Seitentitel und Einstellungen vorhanden sein.  _[desired/desired/ui-navigation/mvp_or_later_unclear]_
- `L048` Ein Logout soll nach dem Login schnell erreichbar sein.  _[desired/desired/ui/sicherheit logout/mvp_or_later_unclear]_
- `L049` Eine Einstellungsseite ist vorgesehen; Admins sollen dort Nutzeraccounts hinzufügen und Rechte anpassen können, alle Nutzer zumindest eigene Profileinstellungen und Sprache.  _[desired/desired/settings/administration/later_possible]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 54 — Speaker 1 ⚠ KEIN KANDIDAT

> Die No-Go-Seite gestalten wir auch so, dass man über einen Plus-Button dann einfach weiterhin neue No-Gos hinzufügen kann, die dynamisch wachsen. Dann hat man eine Liste von Punkten, die nicht klar gehen. Da kann sich jeder im Vorhinein informieren. Hubert beispielsweise macht das ja auch nicht, wenn man ihn berührt.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): No-Go-Eintraege sollen dynamisch ueber einen Plus-Button erweiterbar sein; Nutzer sollen sich vorab informieren koennen, was bei einem Bewohner nicht geht.
- NOISE (irrelevanter Kandidat): 

---

## Segment 55 — Speaker 2 ⚠ KEIN KANDIDAT

> Ja, das klingt nach einem soliden Plan. Ich denke, diese Struktur wird uns und den Endnutzern helfen, effektiv zu arbeiten und die Bedürfnisse der Bewohner besser zu unterstützen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 56 — Speaker 1 ⚠ KEIN KANDIDAT

> Definitiv. Lass uns das alles zusammenfassen und sicherstellen, dass wir nichts Übersehenes haben. Danach können wir den aktuellen Stand, dem Einrichtung-NoName, vorstellen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 57 — Speaker 2 ⚠ KEIN KANDIDAT

> Perfekt. Machen wir das. 4. Interview-Fachpersonal

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 58 — Speaker 1 ⚠ KEIN KANDIDAT

> Ihre Idee ist sehr gut und gefällt uns. Ein paar Sachen müssen aber noch geklärt werden. Wie sieht es mit dem Thema Datenschutz aus, da es sich schon um sehr sensible Daten handelt?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 59 — Speaker 2

> Was das Thema Datenschutz angeht, werden wir nicht allzu tief ins Detail gehen. Dieser Schritt wäre vermutlich ein zusätzliches Projekt. Wir haben uns das aber so überlegt, dass wir eine Login-Seite programmieren, auf der man sich nur einloggen kann, wenn man einen Account zugewiesen bekommen hat. Man hat also nicht die Möglichkeit, sich die App runterzuladen und sich zu registrieren und sich so einen Account anzulegen. Warum? Damit ist auch klar, dass diese App nur für den internen Gebrauch der KYOS wie gedacht ist und sich nicht beliebig jeder anmelden kann. Ein Account, der mit Adminrechten versehen ist, kann dann neue Accounts anlegen und Rechte verwalten. Es gibt also den Power-Nutzer-Admin und den Nutzer-User. Der User hat logischerweise weniger Rechte und kann keine Accounts erstellen oder hinzugefügte Daten aus der App löschen, während der Admin alles kann.

**Auto-Kandidaten (5):**
- `L024` Die App soll nur nach Login zugänglich sein; offene Selbstregistrierung ist nicht vorgesehen.  _[decided/must/zugriffsschutz/authentifizierung/mvp]_
- `L025` Accounts sollen durch einen Admin angelegt und verwaltet werden; es gibt mindestens Rollen Admin und User.  _[decided/must/rollen- und rechtemodell/mvp]_
- `L026` User sollen Inhalte hinzufügen, aber keine Daten löschen können; Admins können alles.  _[decided/must/rechte auf inhaltsänderung/mvp]_
- `L027` Die App ist für internen Gebrauch gedacht und soll nicht beliebig von externen Personen genutzt werden.  _[decided/must/nutzungskreis/mvp]_
- `L045` Beim Thema Datenschutz wird vorerst nicht tief ins Detail gegangen; eine vollständige Datenschutzlösung wäre eher ein separates Zusatzprojekt.  _[open/must_note/projektgrenze datenschutz/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 60 — Speaker 1 ⚠ KEIN KANDIDAT

> Okay, dann belassen wir das Thema Datenschutz fürs Erste. Wie wird das geregelt zwischen den unterschiedlichen Einrichtungen? Die KYOSW hat ja nicht nur eine. Also hat jeder Mitarbeiter in jeder Einrichtung Einsicht auf alle Profile der Beeinträchtigten oder nur auf die in dem Haus, in dem er tätig ist?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Der Zugriff zwischen mehreren Einrichtungen ist als offene Datenschutz-/Rechtefrage explizit zu klaeren.
- NOISE (irrelevanter Kandidat): 

---

## Segment 61 — Speaker 2 ⚠ KEIN KANDIDAT

> Das ist eine gute Frage. Wie hätten Sie es denn gerne? Was macht denn am meisten Sinn?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 62 — Speaker 1

> Aufgrund von Datenschutz sollte es so geregelt sein, dass es nicht übergreifend ist. Also ein Mitarbeiter aus dem Salzburger sollte nur diese Profile sehen von den Bewohnern, die auch tatsächlich im Salzburger Weg sind.

**Auto-Kandidaten (1):**
- `L030` Mitarbeiter sollen aus Datenschutzgründen nicht einrichtungsübergreifend alle Profile sehen; Sichtbarkeit soll auf die jeweils zuständige Einrichtung beschränkt sein.  _[decided/must/mandanten-/einrichtungsabgrenzung/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 63 — Speaker 2

> Alles klar, so wird das gemacht. Wir werden uns einen Weg überlegen, wie man das lösen könnte und bis zum nächsten Treffen erarbeiten.

**Auto-Kandidaten (2):**
- `L030` Mitarbeiter sollen aus Datenschutzgründen nicht einrichtungsübergreifend alle Profile sehen; Sichtbarkeit soll auf die jeweils zuständige Einrichtung beschränkt sein.  _[decided/must/mandanten-/einrichtungsabgrenzung/mvp_or_later_unclear]_
- `L031` Die technische Umsetzung der einrichtungsbezogenen Zugriffsbeschränkung ist noch auszuarbeiten.  _[open/must_clarify/mandantenkonzept umsetzung/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 64 — Speaker 1 ⚠ KEIN KANDIDAT

> Da es eine App ist, stellt sich die Frage, für welches Handysystem? Also Apple, iPhone oder Android, wie machen Sie das?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Die Ziel-Handysysteme bzw. iOS/Android-Unterstuetzung werden als Plattformfrage explizit aufgeworfen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 65 — Speaker 2

> Wir könnten das so machen, dass wir eine plattformübergreifende Programmiersprache nutzen, die sowohl auf einem iPhone als auch auf einem Android-Handy laufen wird.

**Auto-Kandidaten (1):**
- `L032` Die App soll plattformübergreifend auf iPhone/iOS und Android laufen.  _[desired/desired/client-plattformen/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 66 — Speaker 1

> Das wäre ideal. Dann können die App mehr Leute nutzen. Wird es auch auf einem Tablet laufen? Also könnte man die App auch auf einem Tablet laden und nutzen. Dadurch würde sich auch die Datenschutzthematik leichter gestalten, weil dann zum Beispiel einfach die Tablets oder zwei, die in der Einrichtung zur Verfügung stehen, genutzt werden.

**Auto-Kandidaten (2):**
- `L032` Die App soll plattformübergreifend auf iPhone/iOS und Android laufen.  _[desired/desired/client-plattformen/mvp_or_later_unclear]_
- `L033` Tablet-Unterstützung soll evaluiert werden, auch weil stationäre Tablets die Datenschutzthematik erleichtern könnten.  _[open/must_clarify/tablet-support/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 67 — Speaker 2

> Auch das nehmen wir zu den Anforderungen auf und evaluieren, ob das umsetzbar sein wird oder nicht.

**Auto-Kandidaten (1):**
- `L033` Tablet-Unterstützung soll evaluiert werden, auch weil stationäre Tablets die Datenschutzthematik erleichtern könnten.  _[open/must_clarify/tablet-support/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 68 — Speaker 1

> Wenn man auf der Profilseite ist, wo man eine Liste der Profile hat, sollte man nach einem Profil suchen können, um nicht ewig zu scrollen. Also was ich meine, ist eine Art Suchleiste, wo man ganz einfach den Namen eintippen kann und dann nur dieses Profil angezeigt wird.

**Auto-Kandidaten (1):**
- `L034` Auf der Profilübersicht soll eine Suchleiste vorhanden sein, um Bewohnerprofile schnell zu finden.  _[decided/must/profilsuche/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 69 — Speaker 2

> Okay, das hört sich sinnvoll an und das werden wir definitiv umsetzen. Vielleicht sollte diese Suchfunktion mittels einer Suchleiste oben im Bildschirm auch bei den Kommunikationsseiten möglich sein. Als Beispiel haben wir ja den Hubert, den wir kennenlernen durften. Er zeigt gerne Sachen mit seinem Fuß und deutet damit etwas. Dafür wäre es doch sehr sinnvoll, einfach nach Fuß zu suchen und dann nur die Ergebnisse zu sehen, die mit dem Fuß zu tun haben.

**Auto-Kandidaten (2):**
- `L034` Auf der Profilübersicht soll eine Suchleiste vorhanden sein, um Bewohnerprofile schnell zu finden.  _[decided/must/profilsuche/mvp_or_later_unclear]_
- `L035` Auch auf Kommunikationsseiten soll eine Suchfunktion vorhanden sein, z. B. um nach Begriffen wie einem Körperteil zu filtern.  _[decided/must/suche in kommunikationsdaten/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 70 — Speaker 1

> Ja, das ist sehr gut. Dafür könnte man sich ein Muster überlegen. Wie man seine Beschreibung beim Hinzufügen des Bildes oder Ähnlichem formulieren soll, damit man später besser suchen kann. Also als Beispiel zuerst die Art, wie das Körperteil und dann die Beschreibung. So könnte man vor allem bei der nonverbalen Seite, wo man eh davon ausgeht, dass ein Bewohner mit Körperteilen versucht zu kommunizieren, besser filtern. Das ist eine sehr gute Idee.

**Auto-Kandidaten (3):**
- `L035` Auch auf Kommunikationsseiten soll eine Suchfunktion vorhanden sein, z. B. um nach Begriffen wie einem Körperteil zu filtern.  _[decided/must/suche in kommunikationsdaten/mvp_or_later_unclear]_
- `L036` Für Kommunikationsbeschreibungen soll ein systematisches Eingabemuster bzw. Standard entwickelt werden, um spätere Suche und Filterung zu erleichtern.  _[open/must_clarify/standardisierte eingabe kommunikationsdaten/mvp_or_later_unclear]_
- `L037` Ein konkretes vorgeschlagenes Beschreibungsmuster ist, zuerst das Körperteil und dann Aktion bzw. Interpretation zu erfassen.  _[desired/desired/eingabedialog kommunikationsdaten/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 71 — Speaker 2

> Alles klar, das lässt sich umsetzen. Eventuell könnten Sie sich eine genauere Art der Formulierung überlegen und uns diese dann nennen, so wie Sie es letztendlich gerne hätten. Dann können wir es genauso implementieren. Ansonsten werden wir natürlich erstmal eine eigene Art implementieren.

**Auto-Kandidaten (1):**
- `L036` Für Kommunikationsbeschreibungen soll ein systematisches Eingabemuster bzw. Standard entwickelt werden, um spätere Suche und Filterung zu erleichtern.  _[open/must_clarify/standardisierte eingabe kommunikationsdaten/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 72 — Speaker 1 ⚠ KEIN KANDIDAT

> Ich kümmere mich darum.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 73 — Speaker 2

> Was halten Sie generell von der Idee mit den Kommunikationsseiten? Ich denke gerade auch, dass es vielleicht mehr Sinn machen würde, einfach den Videoscreen und die Kommunikationsscreens zusammenzufügen. Also, dass im Kommunikationsscreen bei nonverbal und verbal eben die Möglichkeit besteht, Videos mit Beschreibungen hinzuzufügen. Dies würde einen Screen ersparen und mehr Sinn machen. Schließlich werden sehr viele Videos auf eine Kommunikationsart hindeuten, die man zuerst wahrscheinlich entweder unter nonverbal oder verbal suchen würde. Dabei wäre das Video hilfreicher und nicht sofort auffindbar, da es ausgelagert ist. Also, wir sollten die Videofunktionalitäten in die Kommunikationsseiten einbauen. Was sagen Sie dazu oder wie wäre es Ihnen denn lieber?

**Auto-Kandidaten (1):**
- `L038` Die ursprünglich separate Videoseite soll stattdessen mit den Kommunikationsseiten zusammengeführt werden, sodass bei verbal/nonverbal auch Videos mit Beschreibungen hinzugefügt werden können.  _[decided/must/informationsarchitektur video/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 74 — Speaker 1

> Ich finde, so macht es am meisten Sinn. Machen Sie es genauso, wie Sie es gerade beschrieben haben. Natürlich mit der Suchfunktion.

**Auto-Kandidaten (1):**
- `L038` Die ursprünglich separate Videoseite soll stattdessen mit den Kommunikationsseiten zusammengeführt werden, sodass bei verbal/nonverbal auch Videos mit Beschreibungen hinzugefügt werden können.  _[decided/must/informationsarchitektur video/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 75 — Speaker 2 ⚠ KEIN KANDIDAT

> Alles klar. Wir nehmen das in die Anforderungen auf.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 76 — Speaker 1 ⚠ KEIN KANDIDAT

> Wir hätten mit der App tatsächlich die ideale Lösung für neue Mitarbeiter und generelle Situationen, wo die Beeinträchtigten allein das erste Mal mit jemandem sind und sich verständigen müssen. Die App wächst dynamisch und alle neuen Erfahrungen können sofort geteilt werden. Auch wenn ein neuer Bewohner in eine der Einrichtungen kommt, besteht die Möglichkeit, dass im Vorhinein die Angehörigen Daten in die App einpflegen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Die dynamisch wachsende App soll neue Erfahrungen sofort teilbar machen; das gilt insbesondere fuer neue Mitarbeiter, Erstkontakte und neue Bewohner mit Vorabdaten durch Angehoerige.
- NOISE (irrelevanter Kandidat): 

---

## Segment 77 — Speaker 2

> Genau, das haben wir uns auch gedacht. Der About Me Screen wird auch die Angehörigen erfreuen, da sie da immer sehen können, was die Bewohner so unternehmen. Jedes Mal, wenn etwas Neues im About Me Bildschirm hochgeladen wird, sollen alle User, die mit der App verbunden sind und Teil der Einrichtung sind, eine Popup-Nachricht erhalten.

**Auto-Kandidaten (1):**
- `L039` Wenn im About-Me-Bereich etwas Neues hochgeladen wird, sollen verbundene Nutzer der Einrichtung eine Popup-Benachrichtigung erhalten.  _[desired/desired/benachrichtigungen about me/later_possible]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 78 — Speaker 1

> Das ist eine sehr schöne Idee. Dies würde auch dafür sorgen, dass auch Nutzer der App, die schon alles in- und auswendig kennen, sie immer noch weiterhin nutzen. Sehr gut. Da fällt mir aber noch eine Idee ein. Wieso sollte der Bewohner nicht auch einen Account bei der App haben? Also, dass es sozusagen neben dem Admin- und User-Account Rechten eben auch noch einen Account mit Rechten für den Bewohner gibt. Schließlich könnte er dann das Handy mit der App auch immer an jemanden selber geben, damit die Person dann auch Zugriff darauf hat, im Falle dessen, dass eine Kommunikation fehlschlägt. Oder er könnte selbst Bilder im Account About Me Bildschirm hinzufügen, sofern er das selbst schafft.

**Auto-Kandidaten (3):**
- `L039` Wenn im About-Me-Bereich etwas Neues hochgeladen wird, sollen verbundene Nutzer der Einrichtung eine Popup-Benachrichtigung erhalten.  _[desired/desired/benachrichtigungen about me/later_possible]_
- `L040` Ein spezieller Bewohner-Account wird als gute Idee angesehen, um mehr Autonomie zu ermöglichen.  _[desired/desired/nutzergruppe bewohner/mvp_or_later_unclear]_
- `L043` Bewohner sollen auf den About-Me-Bereich ihres Profils zugreifen und dort ggf. eigene Bilder hinzufügen können.  _[desired/desired/funktionalität bewohner-account/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 79 — Speaker 2

> Sie haben recht. Das ist auch eine sehr gute Idee. Dieser Bewohner-Account sollte aber spezielle Rechte haben und auch nur sein eigenes Profil in der Profilübersicht, wo alle Profile gelistet sind, sehen. Also das, was er wirklich nur seine eigenen Daten sehen kann. 5. Zweite-Ausarbeitung-Stundenten

**Auto-Kandidaten (3):**
- `L040` Ein spezieller Bewohner-Account wird als gute Idee angesehen, um mehr Autonomie zu ermöglichen.  _[desired/desired/nutzergruppe bewohner/mvp_or_later_unclear]_
- `L041` Der Bewohner-Account soll aus Fehlbedienungsgründen stark eingeschränkte Rechte haben.  _[desired/must_consider/rechte bewohner-account/mvp_or_later_unclear]_
- `L042` Ein Bewohner-Account soll nur das eigene Profil sehen können und nicht die Profile anderer Bewohner.  _[decided/must/datensicht bewohner-account/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 80 — Speaker 2 ⚠ KEIN KANDIDAT

> Wir sollten über die neuen Features nachdenken, die wir in unsere App integrieren sollten. Die Gespräche mit den Stakeholdern haben uns ja neuen Input gegeben. Zum Beispiel, was hältst du von dem speziellen Account für Beeinträchtigte?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 81 — Speaker 1

> Das ist eine interessante Idee von dem Fachpersonal. Sie könnten ihr eigenes Profil sehen, was ihnen mehr Autonomie gibt. Sie sollten auf den About Me Screen zugreifen können und dort eigene Bilder hinzufügen. Das würde ihnen sicherlich ein Stück Unabhängigkeit geben.

**Auto-Kandidaten (2):**
- `L040` Ein spezieller Bewohner-Account wird als gute Idee angesehen, um mehr Autonomie zu ermöglichen.  _[desired/desired/nutzergruppe bewohner/mvp_or_later_unclear]_
- `L043` Bewohner sollen auf den About-Me-Bereich ihres Profils zugreifen und dort ggf. eigene Bilder hinzufügen können.  _[desired/desired/funktionalität bewohner-account/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 82 — Speaker 2

> Genau, und wir müssten sicherstellen, dass sie nur diese spezifische Funktion nutzen können, um das Risiko von Fehlbedienungen zu minimieren. Was denkst du über die Implementierung einer Filter- oder Suchleiste auf der Profilübersicht?

**Auto-Kandidaten (1):**
- `L041` Der Bewohner-Account soll aus Fehlbedienungsgründen stark eingeschränkte Rechte haben.  _[desired/must_consider/rechte bewohner-account/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 83 — Speaker 1 ⚠ KEIN KANDIDAT

> Eine Suchleiste würde definitiv helfen, die Navigation zu vereinfachen, besonders wenn wir viele Profile haben. Nutzer können einfach den Namen oder andere relevante Details eingeben, um schneller das gewünschte Profil zu finden.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Die Profil-Suchleiste wird erneut als Navigationshilfe bestaetigt, insbesondere bei vielen Profilen und Suche nach Name oder weiteren Details.
- NOISE (irrelevanter Kandidat): 

---

## Segment 84 — Speaker 2

> Das könnte auch auf der Kommunikationsseite nützlich sein. Wir müssen ein systematisches Beschreibungsmuster für die Eingabe von Kommunikationsweisen entwickeln. So könnten wir beispielsweise festlegen, dass zuerst das Körperteil und dann die Aktion beschrieben wird. Das würde die Suche und das Filtern erleichtern. Also wenn man dann beispielsweise auf den Plus-Button klickt, um etwas Neues hinzuzufügen, könnte der Dialog dafür schon vorgeschrieben sein, wie beispielsweise zuerst ein Feld für Körperteil und dann ein weiteres für Interpretation oder so.

**Auto-Kandidaten (2):**
- `L036` Für Kommunikationsbeschreibungen soll ein systematisches Eingabemuster bzw. Standard entwickelt werden, um spätere Suche und Filterung zu erleichtern.  _[open/must_clarify/standardisierte eingabe kommunikationsdaten/mvp_or_later_unclear]_
- `L037` Ein konkretes vorgeschlagenes Beschreibungsmuster ist, zuerst das Körperteil und dann Aktion bzw. Interpretation zu erfassen.  _[desired/desired/eingabedialog kommunikationsdaten/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 85 — Speaker 1

> Das klingt praktisch. Wir sollten darüber nachdenken, wie wir diese Beschreibungsmuster am besten formulieren. Vielleicht könnten wir sogar ein Tutorial oder eine Hilfe-Seite in der App einbauen, die den Nutzern zeigt, wie sie Informationen am effektivsten eingeben und suchen können.

**Auto-Kandidaten (1):**
- `L044` Ein Tutorial bzw. eine Hilfe-Seite in der App wird erwogen, um standardisierte Eingabe und allgemeine Nutzung zu erklären.  _[open/optional/hilfe/tutorial/later_possible]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 86 — Speaker 2 ⚠ KEIN KANDIDAT

> Ja, eine solche Standardisierung würde die Datenkonsistenz verbessern und die Nutzererfahrung vereinheitlichen. Noch eine Sache. Sollten wir eine Registrierfunktion einbauen oder denkst du, dass es besser wäre, wenn der Admin die Accounts verwaltet, so wie wir es geplant haben?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Standardisierte Eingaben sollen Datenkonsistenz und einheitliche Nutzererfahrung verbessern; offene Registrierfunktion vs. Admin-verwaltete Accounts wird erneut als Sicherheitsentscheidung aufgeworfen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 87 — Speaker 1

> Ich denke, es wäre echt sicherer, wenn nur der Admin die Accounts erstellt und verwaltet. Das verhindert das unbefugte Zugang erhalten. Wir können die Registrierung intern halten, um die Sicherheit und Kontrolle über die App zu bewahren. Wir könnten uns einen Admin-Bildschirm überlegen. Also eine Extra-Seite, die nur ein Account mit Admin-Rechten sehen kann. Auf dieser Seite können wir dann die Funktionalität einbauen, dass neue Accounts angelegt werden können und dafür die drei Rechte Admin, User und Bewohner vergeben werden können. Natürlich müssen wir uns später dann noch überlegen, wie wir das mit der Rechteverwaltung lösen.

**Auto-Kandidaten (1):**
- `L060` Die App soll ohne öffentliche Registrierung gestaltet werden, um unbefugten Zugang zu sensiblen Daten zu verhindern.  _[decided/must_note/sicherheitsbegründung zugangsmodell/mvp]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Der Admin-Bildschirm ist nur teilweise abgedeckt: Er soll exklusiv fuer Admins sichtbar sein und Accounts mit den Rollen Admin, User und Bewohner anlegen/zuweisen; die genaue Rechteverwaltung bleibt offen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 88 — Speaker 2 ⚠ KEIN KANDIDAT

> Gut, so behalten wir die volle Kontrolle darüber, wer Zugang hat. Das könnte vor allem in einer Umgebung, in der sensible Daten gehandhabt werden, sehr wichtig sein. Okay, ich denke, diese Features könnten wirklich einen Mehrwert bieten. Lass uns diese Vorschläge in unser nächstes Meeting einbringen und sehen, was das Team und die Stakeholder denken.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 89 — Speaker 1 ⚠ KEIN KANDIDAT

> Absolut, das klingt nach einem Plan. Es wird spannend sein zu sehen, wie diese Ideen aufgenommen werden und wie sie die App und ihre Funktionalität verbessern können. 6. Dritte-Ausarbeitung-Stundenten

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 90 — Speaker 2 ⚠ KEIN KANDIDAT

> Wir sollten jetzt besprechen, wie wir die Anforderungen implementieren und umsetzen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 91 — Speaker 1 ⚠ KEIN KANDIDAT

> Die erste Frage dabei ist auch, welche Technologien wir verwenden werden. Kennt sich jemand mit Programmiersprachen aus, die es schaffen, Cross-Plattform, iOS und Android zu entwickeln?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 92 — Speaker 2

> Ja, ich habe mal mit dem Framework Flutter und der Programmiersprache Dart eine App entwickelt und bin der Meinung, dass sich das recht schnell lernen lässt und wir damit schon mal abdecken können, dass es sowohl auf einem iOS Handy als auch auf einem Android läuft.

**Auto-Kandidaten (1):**
- `L054` Für die technische Umsetzung wird Flutter mit Dart als Cross-Platform-Stack vorgeschlagen und teamintern vorläufig gewählt.  _[decided/must_note/technologiestack mobile/-]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 93 — Speaker 1 ⚠ KEIN KANDIDAT

> Ja, ich kenne Flutter und Dart auch ein wenig und könnte dabei helfen, wenn jemand im Team Probleme hat. Ansonsten kann ich auch ein YouTube Tutorial empfehlen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 94 — Speaker 2

> Ideal, dann haben wir fürs Erste schon mal geklärt, welche Programmiersprache wir verwenden. Welche Versionen wir verwenden, werde ich jetzt gleich überprüfen und zur Debatte stellen. Die nächste Frage ist, welche Entwicklungsumgebung wir verwenden. Hat hier jemand Vorschläge?

**Auto-Kandidaten (1):**
- `L054` Für die technische Umsetzung wird Flutter mit Dart als Cross-Platform-Stack vorgeschlagen und teamintern vorläufig gewählt.  _[decided/must_note/technologiestack mobile/-]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 95 — Speaker 1 ⚠ KEIN KANDIDAT

> Ich kenne mich mit Visual Studio Code aus und würde diese empfehlen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 96 — Speaker 2 ⚠ KEIN KANDIDAT

> Ich habe Flutter und Dart in Android Studio entwickelt und kenne mich nur damit aus, da es eher IntelliJ ähnelt.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 97 — Speaker 1 ⚠ KEIN KANDIDAT

> Mir ist ein IntelliJ ähnliches System lieber und ich würde deswegen auch Android Studio verwenden.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 98 — Speaker 2 ⚠ KEIN KANDIDAT

> Okay, damit kenne ich mich leider nicht aus, aber es ist ja im Prinzip egal, welche Entwicklungsumgebung verwendet wird.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 99 — Speaker 1

> Naja, es kann schon zu Problemen führen und dann liegt es in deiner Verantwortung, diese zu lösen. Aber es ist natürlich deine freie Entscheidung, obwohl ich trotzdem vorschlagen würde, dass wir alle dieselbe Entwicklungsumgebung nutzen.

**Auto-Kandidaten (1):**
- `L055` Android Studio wird teamintern als gemeinsame Entwicklungsumgebung bevorzugt, um Probleme durch unterschiedliche Umgebungen zu vermeiden.  _[decided/must_note/entwicklungsumgebung/-]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 100 — Speaker 2

> Ja, ich bleibe dabei und wechsle notfalls auch auf Android Studio.

**Auto-Kandidaten (1):**
- `L055` Android Studio wird teamintern als gemeinsame Entwicklungsumgebung bevorzugt, um Probleme durch unterschiedliche Umgebungen zu vermeiden.  _[decided/must_note/entwicklungsumgebung/-]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 101 — Speaker 1

> Ich habe in der Zwischenzeit überprüft, welche Versionen die aktuellsten für Flutter und Dart sind und bin dabei auf Flutter Version 3.13.9 und Flutter 3.1.5 gekommen. Wichtig ist, dass wir dabei alle dieselbe Versionen installieren, damit wir später keine Probleme haben, wenn wir mit der Entwicklung beginnen.

**Auto-Kandidaten (1):**
- `L056` Für das Team sollen einheitliche Flutter- und Dart-Versionen verwendet werden, um Entwicklungsprobleme zu vermeiden.  _[decided/must/entwicklungsprozess/versionierung/-]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 102 — Speaker 2 ⚠ KEIN KANDIDAT

> Perfekt. Wir werden vermutlich auch eine Datenbank brauchen. Hat jemand Vorschläge?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 103 — Speaker 1

> Für die Datenbank würde ich Firebase Firestore von Google empfehlen, da ich diese schon mal mit Flutter und Dart verwendet habe und dazu sagen kann, dass es sehr einfach zu nutzen ist und wir keine speziellen Funktionen brauchen.

**Auto-Kandidaten (1):**
- `L057` Firebase Firestore wird als Datenbank vorgeschlagen; die Nutzung einer Cloud-Datenbank wirft die offene Frage auf, wie Daten lokal auf dem Gerät gespeichert oder gecacht werden.  _[open/must_clarify/datenhaltung cloud/lokal/-]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 104 — Speaker 2

> Okay, aber diese Datenbank fungiert ja dann wie eine Cloud. Wir müssen klären, ob die Daten aus der Cloud dann lokal auf dem Handy gespeichert werden können oder wie das läuft.

**Auto-Kandidaten (1):**
- `L057` Firebase Firestore wird als Datenbank vorgeschlagen; die Nutzung einer Cloud-Datenbank wirft die offene Frage auf, wie Daten lokal auf dem Gerät gespeichert oder gecacht werden.  _[open/must_clarify/datenhaltung cloud/lokal/-]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 105 — Speaker 1

> Ja, dafür habe ich dann die NoSQLite Datenbank verwendet. Ich habe mir das so vorgestellt, dass die App beim Aufrufen einer Seite die Sachen aus Firebase lädt und dann lokal speichert und nicht immer alles erneut aus Firebase lädt.

**Auto-Kandidaten (2):**
- `L057` Firebase Firestore wird als Datenbank vorgeschlagen; die Nutzung einer Cloud-Datenbank wirft die offene Frage auf, wie Daten lokal auf dem Gerät gespeichert oder gecacht werden.  _[open/must_clarify/datenhaltung cloud/lokal/-]_
- `L058` Für lokales Speichern/Caching wurde ergänzend eine lokale NoSQL/SQLite-artige Datenbank als Idee genannt, die genaue Umsetzung ist aber noch offen.  _[open/must_clarify/lokaler cache/offline-speicher/-]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 106 — Speaker 2

> Oh, okay. Also du meinst die NoSQLite Datenbank. Alles klar. Aber bleiben wir erst mal bei Firebase und dann können wir noch weiter schauen, wie wir das umsetzen.

**Auto-Kandidaten (1):**
- `L058` Für lokales Speichern/Caching wurde ergänzend eine lokale NoSQL/SQLite-artige Datenbank als Idee genannt, die genaue Umsetzung ist aber noch offen.  _[open/must_clarify/lokaler cache/offline-speicher/-]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 107 — Speaker 1 ⚠ KEIN KANDIDAT

> Wie sieht es mit der Hardware aus?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 108 — Speaker 2 ⚠ KEIN KANDIDAT

> Meinst du, welches Handy Betriebssystem Version wir verwenden beim Emulator?

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 109 — Speaker 1 ⚠ KEIN KANDIDAT

> Ja, genau.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 110 — Speaker 2

> Ja, dann würde ich empfehlen, dass wir erst mal alle für Android 11 entwickeln, da ich ein echtes Android mit dieser Version besitze, was ich nicht brauche, um die App dann direkt testen zu können. Also dass der Emulator mein echtes Handy ist und keine virtuelle Version in der Entwicklungsumgebung.

**Auto-Kandidaten (1):**
- `L059` Für Entwicklung und Tests soll zunächst Android 11 als Zielversion verwendet werden.  _[decided/must_note/test-/entwicklungszielplattform/-]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 111 — Speaker 1

> Das hört sich perfekt an.

**Auto-Kandidaten (1):**
- `L059` Für Entwicklung und Tests soll zunächst Android 11 als Zielversion verwendet werden.  _[decided/must_note/test-/entwicklungszielplattform/-]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 112 — Speaker 2 ⚠ KEIN KANDIDAT

> Gut, dann hätten wir fürs Erste schon mal die Rahmenbedingungen für die Entwicklung geklärt. Jeder sollte sich jetzt mal alles installieren, um zu schauen, ob alles funktioniert. Im nächsten Teamtreffen klären wir dann die Regeln, wie wir vorgehen bezüglich des Programmierens. Also Comment Regeln etc.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Einheitliche Installation der Entwicklungsumgebung und spaetere Programmier-/Kommentarregeln sollen im naechsten Teamtreffen geklaert werden.
- NOISE (irrelevanter Kandidat): 

---

## Segment 113 — Speaker 1 ⚠ KEIN KANDIDAT

> Ich hätte noch eine Empfehlung. Wir sollten JetX Package verwenden. Habe da gelesen, dass es einen sehr viel Arbeit abnehmen soll.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Das JetX Package wird als moeglicher Entwicklungsbaustein vorgeschlagen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 114 — Speaker 2 ⚠ KEIN KANDIDAT

> Ja, JetX soll tatsächlich sehr gut sein. Nehmen wir das zu den Rahmenbedingungen und schauen dann, wie es damit läuft. Kenne mich sonst nicht damit aus.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Das JetX Package wird zur Pruefung in die Rahmenbedingungen aufgenommen; Nutzen und konkrete Verwendung sind noch offen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 115 — Speaker 1 ⚠ KEIN KANDIDAT

> Alles klar. Bis zum nächsten Mal. Ciao. 8. Design-Ausarbeitung-Studenten

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 116 — Speaker 2 ⚠ KEIN KANDIDAT

> Ok, lasst uns mit dem Design für den Login-Screen anfangen. Ich finde, unser Logo sollte sofort ins Auge fallen, vielleicht im oberen Drittel des Bildschirms zentriert. Am besten ein rundes Logo, aber das Logo müssen wir noch erstellen. Es sollte etwas mit Kommunikation zu tun haben.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Das Logo soll im Login-Screen prominent oben platziert werden, rund sein und thematisch Kommunikation ausdruecken; Logo ist noch zu erstellen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 117 — Speaker 1 ⚠ KEIN KANDIDAT

> Ja, das Logo oben ist gut. Direkt darunter sollten wir das E-Mail- und Passwort-Feld anordnen. Sie müssen intuitiv und benutzerfreundlich sein, vielleicht mit einem leichten Schattenwurf, aber lassen wir das noch offen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Login-UI: E-Mail- und Passwortfeld sollen direkt unter dem Logo stehen und intuitiv/benutzerfreundlich sein.
- NOISE (irrelevanter Kandidat): 

---

## Segment 118 — Speaker 2 ⚠ KEIN KANDIDAT

> Das macht Sinn. Und der Login-Button sollte direkt unter den zwei Feldern sein und hervorstechen. Wir wollen keine Registrierung auf dem Screen, nur den Login, um es schlicht zu halten. Also der Login-Screen besteht aus Logo, E-Mail und Passwort-Feld und einem Login-Button.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Login-UI: Der Screen besteht aus Logo, E-Mail-Feld, Passwort-Feld und hervorgehobenem Login-Button; keine Registrierung auf dem Screen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 119 — Speaker 1

> Genau. Wenn der Nutzer sich eingeloggt hat, leiten wir ihn auf die Profilseite weiter. Nach dem Login sollte auf jeder Seite ganz oben eine Appbar sein. Also eine konsistente Leiste, die drei Hauptfunktionalitäten hat. Links auf der Appbar sollte ein nach links zeigender Pfeil sein. Klickt man den Pfeil an, navigiert man auf die vorherige Seite zurück. In der Mitte der Appbar sollte der Name der aktuellen Seite stehen und rechts ein Einstellungssymbol. Wenn man auf das Einstellungssymbol klickt, landet man auf der Einstellungsseite. Brauchen wir eine konsistente Appbar an der Spitze?

**Auto-Kandidaten (1):**
- `L047` Nach dem Login soll auf allen Seiten eine konsistente Appbar mit Rücknavigation, aktuellem Seitentitel und Einstellungen vorhanden sein.  _[desired/desired/ui-navigation/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 120 — Speaker 2 ⚠ KEIN KANDIDAT

> Stimmt. Unter Titel des aktuellen Screens, in dem Fall Profilübersicht, sollte in der Mitte der Appbar stehen. Unter der Appbar wollen wir eine gut sichtbare Suchleiste einfügen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Die Profiluebersicht soll unter der Appbar eine gut sichtbare Suchleiste anzeigen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 121 — Speaker 1 ⚠ KEIN KANDIDAT

> Die Profile selbst sollten als Kacheln oder Liste unterhalb der Suchleiste angezeigt werden. Jedes mit einem kleinen Vorschaubild, Name und eine kurze Beschreibung des Bewohners. Das gibt einen schnellen Überblick.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Profile sollen als Kacheln oder Liste mit Vorschaubild, Name und Kurzbeschreibung angezeigt werden.
- NOISE (irrelevanter Kandidat): 

---

## Segment 122 — Speaker 2 ⚠ KEIN KANDIDAT

> Und für das Hinzufügen neuer Profile brauchen wir ein klares Plus-Symbol unten auf dem Screen. Ein Dialogfeld sollte erscheinen, wenn man draufklickt, um ein neues Profil mit Bild, Name und Beschreibung anzulegen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Neue Profile sollen ueber ein klares Plus-Symbol unten und einen Dialog mit Bild, Name und Beschreibung angelegt werden koennen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 123 — Speaker 1 ⚠ KEIN KANDIDAT

> Wenn man ein Profil auswählt, sollte die Datenansicht, die Detailansicht unserer Profile-Overview das gewählte Profilbild größer zeigen und die vier Hauptbereiche unserer App als interaktive Buttons darstellen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Die Profildetailansicht soll das Profilbild groesser zeigen und die Hauptbereiche als interaktive Buttons darstellen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 124 — Speaker 2

> Für About Me dachte ich an eine Infobox ganz oben, die Alter, Hobbys etc. enthält. Darunter eine Foto-Timeline, die mit einem Plus-Button am unteren Bildschirmrand neue Einträge ermöglicht. Die neuesten Fotos sollten oben angezeigt werden, ähnlich wie ein Feed in sozialen Medien.

**Auto-Kandidaten (1):**
- `L012` Neue About-Me-Einträge sollen als neueste Elemente oben in einer scrollbaren Liste angezeigt werden.  _[desired/desired/profil/about me darstellung/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 125 — Speaker 1 ⚠ KEIN KANDIDAT

> Auf der Kommunikationsseite wäre es gut, die visuelle Trennung zwischen verbaler und nonverbaler Kommunikation mit Symbolen zu kennzeichnen. Jeder Bereich braucht einen klaren Button, der zu weiteren Informationen führt.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Die Kommunikationsseite soll verbal/nonverbal visuell mit Symbolen trennen und klare Buttons fuer die Bereiche nutzen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 126 — Speaker 2 ⚠ KEIN KANDIDAT

> Ja, und für nonverbale Signale könnte ein Plus-Button hilfreich sein, um Videos und Beschreibungen hinzuzufügen. Das würde es dem Betreuer ermöglichen, schnell nach spezifischen Gesten oder Aktionen zu suchen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Nonverbale Signale sollen ueber Plus-Button mit Videos/Beschreibungen hinzufuegbar und nach Gesten/Aktionen schnell auffindbar sein.
- NOISE (irrelevanter Kandidat): 

---

## Segment 127 — Speaker 1 ⚠ KEIN KANDIDAT

> Auf dem No-Go-Screen müssen wir klare Richtlinien setzen. Ein starkes visuelles Symbol, vielleicht ein rotes Stoppschild, könnte oben auf dem Screen platziert werden. Die Einträge sollten einfach zu durchforsten sein und nur die wichtigsten Informationen enthalten.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): No-Go-Screen: klare Richtlinien, starkes visuelles Symbol und leicht durchsuch-/durchsichtbare Eintraege mit nur wichtigsten Informationen.
- NOISE (irrelevanter Kandidat): 

---

## Segment 128 — Speaker 2 ⚠ KEIN KANDIDAT

> Beim Calendar stimme ich dir zu, dass eine klare monatliche Ansicht ideal ist. Und für Medikamentenerinnerungen könnten wir kleine Icons oder Tags an den entsprechenden Tagen hinzufügen. Ein Touch auf ein Datum öffnet dann Details zum Termin oder zur Medikamentengabel.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Kalender-Design: klare Monatsansicht; Medikamente/Erinnerungen als Icons oder Tags; Tippen auf Datum oeffnet Details zu Termin oder Medikamentengabe.
- NOISE (irrelevanter Kandidat): 

---

## Segment 129 — Speaker 1

> Richtig. Und für den Settings-Screen brauchen wir wirklich eine differenzierte Ansicht, je nach Nutzerrolle. Ein Admin kann dort beispielsweise Nutzeraccounts hinzufügen und Rechte anpassen. Aber jeder Nutzer sollte sein Profil ändern und Einstellungen wie die Sprache wählen können.

**Auto-Kandidaten (1):**
- `L049` Eine Einstellungsseite ist vorgesehen; Admins sollen dort Nutzeraccounts hinzufügen und Rechte anpassen können, alle Nutzer zumindest eigene Profileinstellungen und Sprache.  _[desired/desired/settings/administration/later_possible]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 130 — Speaker 2

> Genau. Wir müssen darauf achten, dass die Datenschutzeinstellungen leicht zugänglich sind und das Ausloggen sollte immer schnell erreichbar sein. Denkst du, wir sollten auch eine Hilfe-Funktion oder ein Tutorial einbauen?

**Auto-Kandidaten (3):**
- `L044` Ein Tutorial bzw. eine Hilfe-Seite in der App wird erwogen, um standardisierte Eingabe und allgemeine Nutzung zu erklären.  _[open/optional/hilfe/tutorial/later_possible]_
- `L048` Ein Logout soll nach dem Login schnell erreichbar sein.  _[desired/desired/ui/sicherheit logout/mvp_or_later_unclear]_
- `L050` Datenschutzeinstellungen sollen leicht zugänglich sein.  _[desired/must_consider/ui/datenschutzoptionen/later_possible]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 131 — Speaker 1

> Auf jeden Fall. Eine kurze Tour durch die App beim ersten Login könnte helfen, die Nutzer mit den Funktionen vertraut zu machen. Und ein Hilfebereich, den man immer wieder aufrufen kann, wäre auch sinnvoll.

**Auto-Kandidaten (1):**
- `L044` Ein Tutorial bzw. eine Hilfe-Seite in der App wird erwogen, um standardisierte Eingabe und allgemeine Nutzung zu erklären.  _[open/optional/hilfe/tutorial/later_possible]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 132 — Speaker 2

> Bei all diesen Screens sollten wir auch die Barrierefreiheit im Auge behalten. Große Schrift, ausreichend Kontrast und die Vermeidung von zu vielen Farben helfen dabei, die App für alle zugänglich zu machen.

**Auto-Kandidaten (1):**
- `L051` Die App soll barrierefrei gestaltet werden, insbesondere mit großer Schrift, ausreichendem Kontrast und Vermeidung zu vieler Farben.  _[desired/desired/barrierefreiheit/usability/mvp_or_later_unclear]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 133 — Speaker 1

> Absolut. Wir sollten vielleicht auch Sprachbefehle oder alternative Eingabemethoden für beeinträchtigte Nutzer berücksichtigen. Was ist mit Animationen oder Feedback? Sollten wir das einbauen?

**Auto-Kandidaten (2):**
- `L052` Sprachbefehle oder alternative Eingabemethoden für beeinträchtigte Nutzer sollen berücksichtigt werden, sind aber noch nicht entschieden.  _[open/must_consider/alternative eingabeformen/later_possible]_
- `L053` Animationen sollen, wenn überhaupt, nicht ablenkend sein; ihr Einsatz ist nicht klar priorisiert.  _[uncertain/must_consider/ui-animationen/later_possible]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 134 — Speaker 2

> Nee, ich denke nicht, dass wir das einbauen sollen. Aber wir sollten darauf achten, dass sie nicht zu ablenkend sind.

**Auto-Kandidaten (1):**
- `L053` Animationen sollen, wenn überhaupt, nicht ablenkend sein; ihr Einsatz ist nicht klar priorisiert.  _[uncertain/must_consider/ui-animationen/later_possible]_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): 
- NOISE (irrelevanter Kandidat): 

---

## Segment 135 — Speaker 1 ⚠ KEIN KANDIDAT

> Gut, dann fassen wir zusammen. Ein zugängliches und intuitives Design mit klarem Branding, ausreichenden Hilfe-Funktionen und starkem Fokus auf Benutzerfreundlichkeit. Lass uns diese Punkte festhalten und dann können wir mit den Prototypen beginnen.

**Auto-Kandidaten (0):**
- _(keine — Segment besonders auf Misses prüfen)_

**Adjudikation:** abgedeckt? ( ) ja  ( ) nein
- MISS (relevanter Claim ohne Kandidat): Zusammenfassung bestaetigt das Designziel: zugaengliches, intuitives Design mit klarem Branding, Hilfe-Funktionen und starkem Fokus auf Benutzerfreundlichkeit.
- NOISE (irrelevanter Kandidat): 

---

## Orphan-Kandidaten (Evidence keinem Segment zugeordnet)

_Deterministisches Matching hat hier kein Segment gefunden (oft paraphrasierte/zusammengesetzte
Evidence). Bitte manuell zuordnen oder als NOISE markieren._

- _(keine)_
