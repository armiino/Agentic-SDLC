# Offene Fragen und Klärungsbedarfe

## Fachliche Fragen
- Wie sollen individuelle Kommunikationsarten strukturiert und dokumentiert werden? Gibt es Vorgaben zu Metadaten oder Standardformaten?
- Wie wird die Balance zwischen Funktionsumfang und Benutzerfreundlichkeit insbesondere für beeinträchtigte Bewohner konkret umgesetzt?
- Welche spezifischen Anforderungen bestehen für die unterschiedlichen Nutzerrollen (Admin, Betreuer, Bewohner) hinsichtlich Bedienbarkeit und Rechte?
- Wer sind die fachlichen Ansprechpartner, insbesondere im Bereich unterstützende Kommunikation, für weitere Detailklärungen?

## Technische Fragen
- Wie wird die dynamische Erweiterbarkeit technisch realisiert? Gibt es bereits Konzepte für modulare Architekturen oder Plugin-Systeme?
- Wie wird die Performance und Kompatibilität auf unterschiedlichen Geräten, vor allem Tablets verschiedener Hersteller, sichergestellt?
- Welche Backend-Architektur wird für Speicherung, Authentifizierung und Rechteverwaltung angestrebt oder empfohlen?

## Widersprüche und Unklarheiten
- Datenschutzanforderungen sind noch offen und können die Architektur und Umsetzung wesentlich beeinflussen.
- Zielkonflikt zwischen umfangreichen Funktionen und einfacher, barrierefreier Bedienbarkeit.
- Unklare Details zur Rechteverwaltung und kontrollierten Nutzerkontenvergabe ohne öffentliche Registrierung.

## Fehlende Informationen
- Konkrete, umsetzbare Datenschutz- und Compliance-Vorgaben.
- Detailierte Spezifikationen zur dynamischen Erweiterbarkeit der Kommunikationsinhalte.
- Detaillierte Definition und Abgrenzung der Nutzerrollen und deren Berechtigungen.

## Ansprechpartner und Rollen
- Datenschutzbeauftragter für Datenschutz- und Compliancefragen.
- Fachliche Experten für unterstützende Kommunikation und Pflege.
- Technische Architekten und Entwickler für Architektur und Machbarkeit.
- Nutzervertreter oder Endanwender zur Sicherstellung der Usability.
