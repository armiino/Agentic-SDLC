## Functional Requirements

- Die App soll plattformübergreifend (Android, iOS, evtl. Tablet) entwickelt werden.
- Die App unterstützt die Kommunikation zwischen Menschen mit Beeinträchtigungen und deren Betreuern durch individuelle Dokumentation der Kommunikationsarten in Text, Bild und Video.
- Nutzerrollen sollen unterschieden werden: Admin, Betreuer/Angehörige (User) und Bewohner.
- Es soll eine Rechteverwaltung implementiert werden, die z. B. eingeschränkte Bedienbarkeit für Bewohnerkonten ermöglicht.
- Nutzerkonten werden kontrolliert vergeben; es ist keine öffentliche Registrierung möglich.
- Die App ermöglicht das Hinzufügen und Erweitern von Kommunikationsweisen, Bildern und Videos dynamisch.
- Such- und Filterfunktionen für Profile und Kommunikationsinhalte werden bereitgestellt.
- Eine Kalenderfunktion für Termine und Medikamentengaben wird integriert.
- Eine No-Go-Liste mit wichtigen Verhaltenshinweisen ist in der App zugänglich.
- Die App verfügt über eine Appbar mit Navigation, Einstellungen und Logout-Funktion.

## Non-functional Requirements

- Die App muss benutzerfreundlich und intuitiv bedienbar sein, insbesondere für beeinträchtigte Bewohner.
- Die technische Umsetzung soll plattformübergreifend erfolgen, bevorzugt mit Flutter/Dart.
- Datenschutz und Zugriffsbeschränkungen müssen hohe Sicherheitsstandards erfüllen.
- Dynamische Erweiterbarkeit der App-Funktionalitäten soll ohne aufwendige Neuinstallationen ermöglicht werden.

## Constraints/Compliance

- Es dürfen keine öffentlichen Registrierungen oder unkontrollierte Zugriffe erlaubt sein.
- Datenschutzregelungen sind zwingend einzuhalten, genaue Anforderungen sind jedoch noch offen und müssen weiter geklärt werden.
- Die App soll die aktuell bekannten rechtlichen Anforderungen im Bereich Datenschutz und Datensicherheit erfüllen.

## Assumptions and Open Points

- Es wird angenommen, dass Flutter/Dart als Technologie zur plattformübergreifenden Entwicklung genutzt wird, da dies angedacht ist.
- Die konkreten Datenschutzvorgaben sind noch nicht abschließend definiert und müssen vor der finalen Umsetzung geklärt werden.
- Die Balance zwischen Funktionsumfang und Bedienbarkeit muss noch final abgestimmt werden.
- Technische Realisierbarkeit und Performance auf den Zielplattformen sind noch zu prüfen.
- Details zur Rechtevergabe und Benutzerrollen können sich noch ändern.

## Traceability

- Ausgangsbasis sind Stakeholder-Interviews und der MAF Shared State Kontext, dokumentiert in input/transcripts/Interview-Einrichtung.txt.
- Anforderungen wurden direkt aus den genannten Projektzielen und Fachthemen abgeleitet.
- Offene Punkte wurden aus den unter "Konflikte und Unsicherheiten" genannten Aspekten übernommen.
