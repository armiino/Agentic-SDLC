# Requirements

## Functional Requirements

FR-1: Das System muss berechtigten Nutzern ermöglichen, für einzelne Bewohner digitale Profile anzulegen und einzusehen.

FR-2: Ein Bewohnerprofil muss mindestens grundlegende personenbezogene Informationen strukturiert darstellen können, darunter Name, Alter, Hobbys sowie allgemeine Informationen über die Person, soweit diese für das Verstehen und die Interaktion im Alltag relevant sind.

FR-3: Das System muss pro Bewohner die Dokumentation individueller Kommunikationsweisen ermöglichen.

FR-4: Die Kommunikationsdokumentation muss zwischen verbalen und nonverbalen Kommunikationsweisen unterscheiden können.

FR-5: Zu dokumentierten Kommunikationsweisen müssen beschreibende Texte hinterlegt werden können.

FR-6: Zu dokumentierten Kommunikationsweisen müssen Bilder mit beschreibenden Erläuterungen hinterlegt werden können.

FR-7: Das System soll die Hinterlegung von Videos zu Kommunikationsweisen oder typischen Situationen unterstützen, sofern die datenschutzrechtlichen und organisatorischen Voraussetzungen geklärt sind.

FR-8: Das System muss die fortlaufende Ergänzung neuer Beobachtungen und Hinweise zu Kommunikationsweisen eines Bewohners ermöglichen.

FR-9: Das System muss Informationen so bereitstellen, dass Nutzer in konkreten Betreuungssituationen relevante Hinweise schnell auffinden können.

FR-10: Das System muss eine Suchfunktion für Bewohnerprofile bereitstellen.

FR-11: Das System soll Such- oder Filtermöglichkeiten innerhalb der dokumentierten Inhalte eines Bewohnerprofils bereitstellen, um Kommunikationshinweise schneller auffinden zu können.

FR-12: Das System muss einen Bereich für kritische Hinweise und No-Go-Informationen je Bewohner bereitstellen.

FR-13: Im Bereich für kritische Hinweise und No-Go-Informationen müssen Warnhinweise, zu vermeidende Reize, Trigger oder klare Verbote im Umgang dokumentiert und abrufbar sein.

FR-14: Das System muss ein rollenbasiertes Zugriffsmodell unterstützen.

FR-15: Das System muss mindestens eine administrative Rolle zur Verwaltung von Zugriffsrechten und Nutzern unterstützen.

FR-16: Das System muss mindestens eine Rolle für reguläre berechtigte Nutzer unterstützen, die Bewohnerinformationen im Rahmen ihrer Berechtigung einsehen und pflegen können.

FR-17: Das System soll die Beteiligung von Angehörigen als gesondert berechtigbare Nutzergruppe unterstützen, damit diese Informationen beisteuern oder einsehen können, sofern dies organisatorisch und datenschutzrechtlich freigegeben ist.

FR-18: Das System soll optional einen stark eingeschränkten Bewohner-Account unterstützen, mit dem ein Bewohner sein eigenes Profil einsehen und in begrenztem Umfang Inhalte beitragen kann, sofern dies fachlich und organisatorisch gewünscht ist.

FR-19: Das System darf Nutzern keinen offenen Zugriff über freie Selbstregistrierung ermöglichen.

FR-20: Das System muss den Zugriff auf Bewohnerprofile nach Einrichtung oder organisatorischem Zuständigkeitsbereich beschränken können, sodass Nutzer nicht automatisch einrichtungsübergreifend auf alle Profile zugreifen können.

FR-21: Das System muss für mobile Nutzung ausgelegt sein.

FR-22: Das System muss eine Profilübersicht bereitstellen, von der aus berechtigte Nutzer zu einzelnen Bewohnerprofilen navigieren können.

FR-23: Das System soll innerhalb eines Bewohnerprofils einen Bereich zur kompakten persönlichen Einführung in die Person bereitstellen.

FR-24: Das System soll Hilfestellungen zur Nutzung bereitstellen, damit neue oder ungeübte Nutzer die Anwendung verstehen können.

FR-25: Das System soll Kalender- oder Termininformationen zu Bewohnern nur dann unterstützen, wenn dadurch der fachliche Fokus auf Kommunikationsunterstützung nicht beeinträchtigt wird; dieser Funktionsbereich ist derzeit nachrangig und fachlich noch nicht final bestätigt.

FR-26: Das System soll Medikamenteninformationen nur dann unterstützen, wenn hierfür eine gesonderte fachliche und datenschutzrechtliche Freigabe vorliegt; dieser Funktionsbereich ist derzeit nicht als bestätigter Kernbestandteil festgelegt.

## Non-functional Requirements

NFR-1: Das System muss im Betreuungsalltag einfach und schnell nutzbar sein.

NFR-2: Das System muss Informationen praxistauglich aufbereiten, sodass relevante Inhalte leichter auffindbar sind als in umfangreicher klassischer Dokumentation.

NFR-3: Das System muss eine klare und leicht verständliche Navigation bieten.

NFR-4: Das System soll auf mobilen Endgeräten mit einer für kurze Nutzungssituationen geeigneten Bedienoberfläche nutzbar sein.

NFR-5: Das System muss die Anforderungen an Barrierefreiheit und benutzerfreundliche Bedienung berücksichtigen.

NFR-6: Die Benutzeroberfläche soll große oder gut lesbare Schriftgrößen unterstützen.

NFR-7: Die Benutzeroberfläche soll ausreichende Kontraste unterstützen.

NFR-8: Die Benutzeroberfläche soll visuell reduziert gestaltet sein, um Ablenkung zu minimieren.

NFR-9: Das System soll Hilfen oder Tutorials zur Einführung in die Nutzung bereitstellen.

NFR-10: Das System soll alternative oder vereinfachte Eingabemethoden unterstützen, sofern dies für die Zielgruppen erforderlich ist.

NFR-11: Das System muss so gestaltet sein, dass es die Wissensweitergabe zwischen erfahrenen und neuen Betreuungspersonen wirksam unterstützt.

NFR-12: Das System muss personenbezogene und besonders sensible Inhalte vertraulich verarbeiten und vor unberechtigtem Zugriff schützen.

NFR-13: Das System muss bei der Darstellung und Pflege von Informationen den sensiblen Charakter der Daten angemessen berücksichtigen.

NFR-14: Das System soll funktional fokussiert bleiben und nicht mit fachlich nachrangigen Funktionen überfrachtet werden.

## Constraints/Compliance

CC-1: Der fachliche Kern des Systems ist die Dokumentation, Aufbereitung und der schnelle Zugriff auf vorhandenes Erfahrungswissen über individuelle Kommunikationsweisen; eine automatische Übersetzung individueller Ausdrucksweisen in Standardsprache ist nicht Bestandteil des Systems.

CC-2: Das System darf keine Funktionen voraussetzen, die den Eindruck einer automatisierten Deutung oder Übersetzung individueller Kommunikation als gesicherte Wahrheit erzeugen.

CC-3: Das System muss den Zugriff auf personenbezogene Daten nur für berechtigte Nutzer im Rahmen eines Rechtekonzepts erlauben.

CC-4: Das System muss organisatorische Zugriffsbeschränkungen nach Einrichtung oder Zuständigkeitsbereich unterstützen.

CC-5: Die Verarbeitung von Bildern und insbesondere Videos darf nur unter Beachtung der dafür geltenden Datenschutz-, Einwilligungs- und Organisationsvorgaben erfolgen.

CC-6: Die Verarbeitung besonders sensibler Inhalte, insbesondere möglicher Medikamenteninformationen, darf nur erfolgen, wenn Zweck, Berechtigung und Schutzmaßnahmen fachlich und organisatorisch geklärt sind.

CC-7: Das System muss so konzipiert werden, dass Angehörigenzugriffe nur bei expliziter Freigabe und klar geregelten Berechtigungen möglich sind.

CC-8: Das System muss dem Umstand Rechnung tragen, dass bestehende Dokumentation bereits vorhanden sein kann; Ziel ist daher vor allem bessere Auffindbarkeit und Alltagstauglichkeit, nicht zwingend der vollständige Ersatz aller bestehenden Akten.

CC-9: Nicht abschließend entschiedene Konzeptoptionen dürfen nicht als verbindlich implementierungspflichtige Kernfunktionen behandelt werden, solange keine fachliche Bestätigung vorliegt.

## Assumptions and Open Points

AOP-1: Es wird angenommen, dass die primäre Zielplattform eine mobile App ist; ob zusätzlich Tablets verbindlich unterstützt werden müssen, ist noch offen.

AOP-2: Es ist offen, wie Datenschutz, Einwilligungen sowie die zulässige Nutzung von Bild- und Videomaterial im Detail geregelt werden.

AOP-3: Es ist offen, ob und in welchem Umfang bestehende Bewohnerakten inhaltlich übernommen, eingesehen oder mit dem System verknüpft werden dürfen.

AOP-4: Es ist offen, ob Videos als eigenständiger Bereich oder ausschließlich integriert in Kommunikationsseiten bereitgestellt werden sollen.

AOP-5: Es ist offen, wie das Rollen- und Rechtemodell im Detail ausgestaltet wird, insbesondere hinsichtlich Angehörigen und Bewohner-Accounts.

AOP-6: Es wird angenommen, dass neue Mitarbeitende und fachfremde Personen eine zentrale Nutzergruppe darstellen, da der Nutzen für Einarbeitung und Alltagshilfe mehrfach betont wurde.

AOP-7: Es ist offen, ob Kalender- und Terminfunktionen Bestandteil des ersten Releases werden sollen.

AOP-8: Es ist offen, ob Medikamenteninformationen überhaupt Bestandteil des Systems werden sollen.

AOP-9: Es ist offen, welche Inhalte Bewohner mit einem möglichen eigenen Account selbst einsehen oder bearbeiten dürfen.

AOP-10: Es wird angenommen, dass die Beteiligung von Angehörigen fachlich erwünscht sein kann, aber von organisatorischen und datenschutzrechtlichen Freigaben abhängt.

AOP-11: Uneinheitliche Organisationsbezeichnungen in der Quelle werden als Inkonsistenz der Ausgangsdokumente behandelt und haben keine eigenständige fachliche Anforderungswirkung.

## Traceability

- FR-1 bis FR-3, FR-8, FR-9, NFR-1, NFR-2, NFR-11, CC-1, CC-8 leiten sich aus dem Projektziel, der Ausgangslage sowie den fachlichen Hauptthemen „Unterstützte Kommunikation“ und „Wissenssicherung und Wissensweitergabe“ ab.

- FR-2 und FR-23 leiten sich aus dem Hauptthema „Bewohnerprofile / personenbezogene Informationen“ sowie dem vorläufigen Lösungsbild mit Profilseiten und About-Me-Bereich ab.

- FR-4 bis FR-7, FR-11 leiten sich aus dem Hauptthema „Kommunikationsdokumentation“ sowie dem Thema „Videos als Interpretationshilfe“ ab.

- FR-12 und FR-13 leiten sich aus dem Hauptthema „No-Go-Informationen / kritische Hinweise“ ab.

- FR-14 bis FR-20 sowie CC-3, CC-4, CC-7 leiten sich aus den Themen „Rollen- und Rechtemanagement“, „Zugriffsbeschränkung nach Einrichtung“ sowie den Spannungen zwischen internem Nutzen, Angehörigenbeteiligung und Datenschutz ab.

- FR-19 leitet sich aus dem vorläufigen Lösungsbild „Login ohne offene Selbstregistrierung“ ab.

- FR-21, FR-22 und NFR-4 leiten sich aus der Zielrichtung einer mobilen, schnell nutzbaren App sowie dem vorläufigen Lösungsbild mit Profilübersicht und Suche ab.

- FR-24 sowie NFR-3, NFR-5 bis NFR-10 leiten sich aus dem Thema „Barrierefreiheit und Benutzerfreundlichkeit“ sowie der Design-Ausarbeitung ab.

- FR-25, FR-26, CC-5, CC-6 sowie AOP-2, AOP-4, AOP-7 und AOP-8 leiten sich aus den als unsicher oder nachrangig beschriebenen Themen Videos, Kalender, Medikamente und Datenschutz ab.

- AOP-1, AOP-3, AOP-5, AOP-9 und AOP-10 leiten sich aus den im Kontext ausdrücklich genannten offenen Punkten und Unsicherheiten ab.
